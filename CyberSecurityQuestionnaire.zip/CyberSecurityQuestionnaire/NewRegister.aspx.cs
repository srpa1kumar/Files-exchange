﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;

public partial class NewRegister : System.Web.UI.Page
{
    string status;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            Captcha1.ValidateCaptcha(txtCaptcha.Text.Trim());

            if (Captcha1.UserValidated)
            {
                if (txtEmail.Text == txtAlterEmail.Text)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert(' Alternate Email Address and Email Address cannot be the same!');</script>");
                }

                else
                {

                    SqlCommand cmd1 = new SqlCommand(@"  select * from [LOGWITHUSER] where  EmailId = '" + txtEmail.Text + "' ", con);
                    SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    if (dt1.Rows.Count > 0)
                    {
                        status = Convert.ToString(dt1.Rows[0]["status"]).ToString();
                        {
                            if (status == "Rejected")
                            {
                                con.Open();
                                string strsqlcommand2 = "UPDATE [dbo].[LOGWITHUSER] SET  [status] = @St ,[Active] = '2' where EmailId = '" + txtEmail.Text + "'";
                                SqlCommand cmd2 = new SqlCommand(strsqlcommand2, con);
                                cmd2.Parameters.AddWithValue("@St", DBNull.Value);
                                int roweffected = cmd2.ExecuteNonQuery();
                                con.Close();
                                Mail();
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Saved Sucessfully and Request sent for Approval, Click OK');window.location ='Default.aspx';", true);
                            }
                            else
                            {
                                ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert(' This EmailId is already Registered!');</script>");
                            }

                        }
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[LOGWITHUSER]([SupplierCompanyName],[Name],[EmailId],[alterEmailId],[alterPhone],[Phone],[Date],[Active],[islocked],[attemptcount])
     VALUES
           ('" + txtCompNme.Text + "','" + txtNme.Text + "','" + txtEmail.Text + "','" + txtAlterEmail.Text + "','" + txtalterPhone.Text + "','" + txtPhone.Text + "','" + System.DateTime.Today + "','" + 0 + "','" + 0 + "','" + 0 + "')", con);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        Mail();
                        ScriptManager.RegisterStartupScript(this, this.GetType(),
                              "alert",
                              "alert('Thank you for registering. Your ID registration is in progress. Once successfully registered, you will be getting a communication through registered email., Click OK');window.location ='Default.aspx';", true);
                    }
                }
            }

            else
            {
                Label1.Visible = true;
                Label1.Text = "Invalid. Please try again.";
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void Mail()
    {
        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");

        ////---------------------Test Email ID------------------------------
        //msg.To.Add("Jaganathan.k@indo-mim.com");
        msg.CC.Add("shalini.r@indo-mim.com");


        msg.Subject = "Request For Approval/Reject - New Registration";
        msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>";
        msg.Body += "<br/><font color='Black'>" + "New Registration on Cyber Security Questionnaire Portal by " + txtNme.Text + "<br/>";
        msg.Body += "<br /> <font color='Black'> Kindly Approve/Reject LINK: <a href='http://192.168.1.73/demopage'>http://192.168.1.73/demopage</a></b><br/><br/>";
        //msg.Body += "<br/><font color='Black'>" + "Kindly Approve/Reject" +  "<br/>";
        msg.Body +=
   "<br/><br/><font color='black'>" + "<b>" +
"UserID:" + txtEmail.Text + "<br/>" +
"Date :" + DateTime.Now.ToString("dd-MM-yyyy") + "<br/>" +
"Time :" + DateTime.Now.ToString("hh:mm:ss tt") + "<br/>" + "<br/>";

        // msg.Subject = "TEST MAIL.PLZ,IGNORE IT";

        msg.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();

        //***** Old Host ID ******
        //smtp.Host = "192.168.1.25";

        //***** New Host ID ******
        smtp.Host = "192.168.1.71";
        smtp.Port = 25;
        smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        try
        {
            smtp.Send(msg);
        }
        catch
        {
        }
    }
}