﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;
using System.IO;

public partial class CyberSecurityQuestionnaire : System.Web.UI.Page
{
    string Name; string EmailID; string Status;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["Name"] == null)
            {
                Response.Redirect("default.aspx");

            }


            EmailID = Session["EmailID"].ToString(); // value of EmailIDTextBox;
            Name = Session["Name"].ToString();

            loadGrid();
            loadGrid1();
            DownloadFile();
            AccOrRej();
        }
    }

    private void AccOrRej()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@"   select Status FROM [ITVendorLicences].[dbo].[VendorCyberSecurity] where [EmailAddress] = '" + EmailID + "' order by id desc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            Status = Convert.ToString(dt.Rows[0]["Status"]);

            if (Status == "Rejected")
            {

                txtQ7Nme.Enabled = true;
                txtQ7desg.Enabled = true;
                txtQ7email.Enabled = true;
                txtQ7Phno.Enabled = true;

                txtQ7Nme1.Enabled = true;
                txtQ7desg1.Enabled = true;
                txtQ7email1.Enabled = true;
                txtQ7Phno1.Enabled = true;

                RdQ8YesNo.Enabled = true;

                RdQ10YesNo.Enabled = true;
                RdQ10.Enabled = true;
                txtFormName.Enabled = true;
                txtFormDesg.Enabled = true;
                txtformDate.Enabled = true;
                btnUpdateSave.Visible = true;

                Updategrid1();
                updategrid2();

                UpdateSoftwareNameVerionGridQ6();
                UpdateSoftwareNameVerionGridQ61();
                UpdateSoftwareNameVerionGridQ9();
                UpdateSoftwareNameVerionGridQ91();

            }

            if (Status == "Approved")
            {
                txtQ7Nme.Enabled = false;
                txtQ7desg.Enabled = false;
                txtQ7email.Enabled = false;
                txtQ7Phno.Enabled = false;

                txtQ7Nme1.Enabled = false;
                txtQ7desg1.Enabled = false;
                txtQ7email1.Enabled = false;
                txtQ7Phno1.Enabled = false;

                RdQ8YesNo.Enabled = false;

                RdQ10YesNo.Enabled = false;
                RdQ10.Enabled = false;
                txtFormName.Enabled = false;
                txtFormDesg.Enabled = false;
                txtformDate.Enabled = false;
                btnUpdateSave.Visible = false;

                grid1();
                grid2();

                SoftwareNameVerionGridQ6();
                SoftwareNameVerionGridQ61();
                SoftwareNameVerionGridQ9();
                SoftwareNameVerionGridQ91();
            }

            if (Status == "")
            {
                grid1();
                grid2();

                SoftwareNameVerionGridQ6();
                SoftwareNameVerionGridQ61();
                SoftwareNameVerionGridQ9();
                SoftwareNameVerionGridQ91();
            }
        }
    }

    private void grid1()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@"  select ROW_NUMBER() OVER(ORDER BY date asc) AS ID,[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[T1SoftwareName],[T1Version],
  [T1Description],[T1LicenseType],[T1LicenseSubscriptionModel],CONVERT(varchar,T1ValidFrom,1)[T1ValidFrom],CONVERT(varchar,T1ValidTill,1)[T1ValidTill] from [ITVendorLicences].[dbo].[VendorCyberSecurityGrid1]
  where [EmailAddress] = '" + EmailID + "' order by id desc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            Gridview1.DataSource = dt;
            Gridview1.DataBind();
        }
    }

    private void grid2()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@"  SELECT  ROW_NUMBER() OVER(ORDER BY date asc) AS ID,[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[T2SoftwareName],[T2Version],[T2SoftwareVendorName]
      ,[T2LicenseUsageModel],[T2LicenseDistribution],CONVERT(varchar,Date,1)[Date] FROM [ITVendorLicences].[dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + EmailID + "' order by id desc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            Gridview2.DataSource = dt;
            Gridview2.DataBind();
        }
    }


    private void Updategrid1()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@"  select ROW_NUMBER() OVER(ORDER BY date asc) AS ID,[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[T1SoftwareName],[T1Version],
  [T1Description],[T1LicenseType],[T1LicenseSubscriptionModel],CONVERT(varchar,T1ValidFrom,1)[T1ValidFrom],CONVERT(varchar,T1ValidTill,1)[T1ValidTill] from [ITVendorLicences].[dbo].[VendorCyberSecurityGrid1] 
  where [EmailAddress] = '" + txtEmail.Text + "' order by id asc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            UpdateGridview1.DataSource = dt;
            UpdateGridview1.DataBind();
        }
    }

    private void updategrid2()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@"  SELECT  ROW_NUMBER() OVER(ORDER BY date asc) AS ID,[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[T2SoftwareName],[T2Version],[T2SoftwareVendorName]
      ,[T2LicenseUsageModel],[T2LicenseDistribution],CONVERT(varchar,Date,1)[Date] FROM [ITVendorLicences].[dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "' order by id asc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            UpdateGridview2.DataSource = dt;
            UpdateGridview2.DataBind();
        }
    }

    private void DownloadFile()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@" select id, [ContentName] ,[ContentType],[Content]from [ITVendorLicences].[dbo].[VendorCyberFileUpload] where [EmailAddress] = '" + EmailID + "' ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            GridView3.DataSource = dt;
            GridView3.DataBind();
        }
    }


    protected void loadGrid()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@" Select * from [LOGWITHUSER] where EmailId = '" + EmailID + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                txtSupCompNme.Text = Convert.ToString(dt.Rows[0]["SupplierCompanyName"]);
                txtName.Text = Convert.ToString(dt.Rows[0]["Name"]);
                txtEmail.Text = Convert.ToString(dt.Rows[0]["EmailId"]);
                txtphone.Text = Convert.ToInt64(dt.Rows[0]["Phone"]).ToString();
            }
        }
        catch
        {

        }
        con.Close();
    }


    protected void loadGrid1()
    {
        //try
        //{
            con.Open();
            SqlCommand cmd = new SqlCommand(@"SELECT  [Id],[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[Q7Name],[Q7Designation]
,[Q7EmailAddress],[Q7PhoneNumber],[Q7Name1],[Q7Designation1],[Q7EmailAddress1],[Q7PhoneNumber1],[Q8YesOrNo],[Q9YesOrNo],[Q9Remarks1]
,[Q9Remarks2],[Q10YesOrNo],[Q10mitigation],[FormFilledByName],[FormFilledByDesignation],[FormFilledByDateOfSubmission],[Status]
  FROM [ITVendorLicences].[dbo].[VendorCyberSecurity] where [EmailAddress] = '" + EmailID + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {

                txtQ7Nme.Text = Convert.ToString(dt.Rows[0]["Q7Name"]).ToString();
                txtQ7desg.Text = Convert.ToString(dt.Rows[0]["Q7Designation"]);
                txtQ7email.Text = Convert.ToString(dt.Rows[0]["Q7EmailAddress"]);
                txtQ7Phno.Text = Convert.ToInt64(dt.Rows[0]["Q7PhoneNumber"]).ToString();

                txtQ7Nme1.Text = Convert.ToString(dt.Rows[0]["Q7Name1"]).ToString();
                txtQ7desg1.Text = Convert.ToString(dt.Rows[0]["Q7Designation1"]);
                txtQ7email1.Text = Convert.ToString(dt.Rows[0]["Q7EmailAddress1"]);
                txtQ7Phno1.Text = Convert.ToInt64(dt.Rows[0]["Q7PhoneNumber1"]).ToString();

                RdQ8YesNo.Text = Convert.ToString(dt.Rows[0]["Q8YesOrNo"]);

                RdQ10YesNo.Text = Convert.ToString(dt.Rows[0]["Q10YesOrNo"]);
                RdQ10.Text = Convert.ToString(dt.Rows[0]["Q10mitigation"]);
                txtFormName.Text = Convert.ToString(dt.Rows[0]["FormFilledByName"]);
                txtFormDesg.Text = Convert.ToString(dt.Rows[0]["FormFilledByDesignation"]).ToString();
                txtformDate.Text = Convert.ToDateTime(dt.Rows[0]["FormFilledByDateOfSubmission"]).ToString();
            }
        //}
        //catch
        //{

        //}
        con.Close();
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        byte[] documentBinary;
        GridViewRow gvr = ((Button)sender).Parent.Parent as GridViewRow;
        Label ID = (Label)gvr.FindControl("ID");
        string filename = string.Empty;
        con.Open();
        SqlCommand com = new SqlCommand(" select id, [ContentName] ,[ContentType],[Content]from [ITVendorLicences].[dbo].[VendorCyberFileUpload] where [EmailAddress] = '" + txtEmail.Text + "' and id = '" + ID.Text + "' ", con);

        try
        {
            using (SqlDataReader sdr = com.ExecuteReader())
            {
                sdr.Read();
                // bytes = (byte[])sdr["fileattachment"];
                documentBinary = (byte[])sdr["Content"];

                filename = sdr["ContentName"].ToString();
            }
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + filename);
            Response.BinaryWrite(documentBinary);
            Response.Flush();
            Response.End();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert(' Attachment Not Available/ Error in Server');</script>");
        }
    }
   

   
    protected void mail()
    {
        //MailMessage msg = new MailMessage();
        //msg.From = new MailAddress("communiq@indo-mim.com","");
        //msg.To.Add(txtEmail.Text);
        ////msg.CC.Add("Jaganathan.k@indo-mim.com");
        //msg.CC.Add("shalini.r@indo-mim.com");

        //msg.Subject = "Vendor Cyber Security Questionnaire ";

        //msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";
        //msg.Body += "<table style='width:450px'><tr><td><div align='center' style='width:400px; background-color: #0066CC; font-family: Calibri; font-size: medium; font-weight: bold; color: #FFFFFF;'> Please find below Vendor Cyber Security Questionnaire Details </div></td></tr><tr><td></td> </tr> <tr><td><table border='1' style='border: thin solid #C0C0C0; width: 450px;  font-family: Calibri;'><tr> <td>UserName</td><td>" + Convert.ToString(txtEmail.Text) + "</td></tr>  <tr><td></td><td> </tr> </table>" + "<br/>";


        //msg.IsBodyHtml = true;
        //SmtpClient smtp = new SmtpClient();
        //smtp.Host = "192.168.1.71";
        //smtp.Port = 25;
        //smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        //ScriptManager.RegisterStartupScript(this, this.GetType(),
        //            "alert",
        //            "alert('Approved & mail sent to User successfully., Click OK');window.location ='NewQuestionnaireApproval.aspx';", true);
        //try
        //{
        //    smtp.Send(msg);
        //}
        //catch
        //{
        //}



        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");

        ////---------------------Test Email ID------------------------------
        msg.To.Add("Jaganathan.k@indo-mim.com");
        msg.CC.Add("shalini.r@indo-mim.com");


        msg.Subject = "Request For Approval/Reject";
        msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>";
        msg.Body += "<br/><font color='Black'>" + "Edited the rejected details on Cyber Security Questionnaire Portal by " + txtName.Text + "<br/>";
        msg.Body += "<br /> <font color='Black'> Kindly Approve/Reject LINK: <a href='http://192.168.1.73/demopage'>http://192.168.1.73/demopage</a></b><br/><br/>";
        //msg.Body += "<br/><font color='Black'>" + "Kindly Approve/Reject" +  "<br/>";
        msg.Body +=
   "<br/><br/><font color='black'>" + "<b>" +
"UserID:" + txtEmail.Text + "<br/>" +
"Date :" + DateTime.Now.ToString("dd-MM-yyyy") + "<br/>" +
"Time :" + DateTime.Now.ToString("hh:mm:ss tt") + "<br/>" + "<br/>";

        // msg.Subject = "TEST MAIL.PLZ,IGNORE IT";

        msg.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();

        //***** Old Host ID ******
        //smtp.Host = "192.168.1.25";

        //***** New Host ID ******
        smtp.Host = "192.168.1.71";
        smtp.Port = 25;
        smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        try
        {
            smtp.Send(msg);
        }
        catch
        {
        }
    }

    protected void UpdateGridview1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        UpdateGridview1.EditIndex = -1;
        this.Updategrid1();
    }
    protected void UpdateGridview1_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void UpdateGridview1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label id = (Label)UpdateGridview1.Rows[e.RowIndex].FindControl("id");
        TextBox SoftwareName = (TextBox)UpdateGridview1.Rows[e.RowIndex].FindControl("EditT1SoftwareName") as TextBox; 
        TextBox Version = (TextBox)UpdateGridview1.Rows[e.RowIndex].FindControl("EditT1Version") as TextBox; 
        TextBox Description = (TextBox)UpdateGridview1.Rows[e.RowIndex].FindControl("EditT1Description") as TextBox;
        DropDownList License = (DropDownList)UpdateGridview1.Rows[e.RowIndex].FindControl("ddlLicType");
        DropDownList LicenseSubscriptionModel = (DropDownList)UpdateGridview1.Rows[e.RowIndex].FindControl("ddlLicense1");
        TextBox ValidFrom = (TextBox)UpdateGridview1.Rows[e.RowIndex].FindControl("EditT1ValidFrom") as TextBox;
        TextBox ValidTill = (TextBox)UpdateGridview1.Rows[e.RowIndex].FindControl("EditT1ValidTill") as TextBox;

    
        SqlCommand cmd = new SqlCommand(@"UPDATE [dbo].[VendorCyberSecurityGrid1]
   SET [T1SoftwareName] = '" + SoftwareName.Text + "',[T1Version] = '" + Version.Text + "',[T1Description] =  '" + Description.Text + @"'
,[T1ValidFrom] = '" + ValidFrom.Text + "',[T1ValidTill] = '" + ValidTill.Text + "', [T1LicenseType] = '" + License.Text + @"'
,[T1LicenseSubscriptionModel] = '" + LicenseSubscriptionModel.Text + @"'
 WHERE EmailAddress = '" + txtEmail.Text + "' and Id = '"+id.Text+"' ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        con.Open();
        cmd.ExecuteNonQuery();
        //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
        UpdateGridview1.EditIndex = -1;
        //Call ShowData method for displaying updated data  
        con.Close();
        Updategrid1();
    }


 
    
    protected void UpdateGridview2_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        UpdateGridview2.EditIndex = -1;
        this.updategrid2();
    }
    protected void UpdateGridview2_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

    protected void UpdateGridview2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label id = (Label)UpdateGridview2.Rows[e.RowIndex].FindControl("id");
        TextBox SoftwareName1 = (TextBox)UpdateGridview2.Rows[e.RowIndex].FindControl("T2SoftwareName") as TextBox;
        TextBox Version1 = (TextBox)UpdateGridview2.Rows[e.RowIndex].FindControl("T2Version") as TextBox;
        TextBox SoftwareVendorName1 = (TextBox)UpdateGridview2.Rows[e.RowIndex].FindControl("T2SoftwareVendorName") as TextBox;
        TextBox LicenseUsageModel = (TextBox)UpdateGridview2.Rows[e.RowIndex].FindControl("T2LicenseUsageModel") as TextBox;
        TextBox LicenseDistribution1 = (TextBox)UpdateGridview2.Rows[e.RowIndex].FindControl("T2LicenseDistribution") as TextBox;


        SqlCommand cmd = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurityGrid2] SET [T2SoftwareName] = '" + SoftwareName1.Text + "',[T2Version] = '" + Version1.Text + @"'
      ,[T2SoftwareVendorName] = '" + SoftwareVendorName1.Text + "',[T2LicenseUsageModel] = '" + LicenseUsageModel.Text + "',[T2LicenseDistribution] = '" + LicenseDistribution1.Text + @"'
       WHERE EmailAddress = '" + txtEmail.Text + "'  and Id = '" + id.Text + "'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        con.Open();
        cmd.ExecuteNonQuery();
        //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
        UpdateGridview2.EditIndex = -1;
        //Call ShowData method for displaying updated data  
        con.Close();
        updategrid2();
    }


    protected void btnUpdateSave_Click(object sender, EventArgs e)
    {
        UpdateSave();
    }

   
    protected void UpdateSave()
    {
        try
        {
            SqlCommand cmd1 = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurity] SET [Q7Name] = '" + txtQ7Nme.Text + "',[Q7Designation] = '" + txtQ7desg.Text + "',[Q7EmailAddress] = '" + txtQ7email.Text + @"'
,[Q7PhoneNumber] = '" + txtQ7Phno.Text + "',[Q7Name1] = '" + txtQ7Nme1.Text + "',[Q7Designation1] = '" + txtQ7desg1.Text + "',[Q7EmailAddress1] = '" + txtQ7email1.Text + @"' 
,[Q7PhoneNumber1] = '" + txtQ7Phno1.Text + "',[Q8YesOrNo] = '" + RdQ8YesNo.Text + "',[Q10YesOrNo]='" + RdQ10YesNo.Text + "',[Q10mitigation]='" + RdQ10.Text + "' ,[FormFilledByName]='" + txtFormName.Text + @"',
[FormFilledByDesignation]='" + txtFormDesg.Text + "',[FormFilledByDateOfSubmission]='" + txtformDate.Text + @"',status = NULL       
        WHERE [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            con.Open();
            cmd1.ExecuteNonQuery();
            con.Close();
            mail();
            ScriptManager.RegisterStartupScript(this, this.GetType(),
    "alert",
    "alert('Data Updated Successfully, Click OK');window.location ='Edit_VendorCyberSecurityQuestionnaire.aspx';", true);
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }

    }

    protected void SoftwareNameVerionGridQ6()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select ([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q6YesNo],[Q6Remarks]   from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridViewQ6.DataSource = dt;
                GridViewQ6.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void SoftwareNameVerionGridQ61()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select ([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q6YesNo1],[Q6Remarks1]  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridViewQ61.DataSource = dt;
                GridViewQ61.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void SoftwareNameVerionGridQ9()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select ([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q9YesNo],[Q9Remarks]   from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridViewQ9.DataSource = dt;
                GridViewQ9.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void SoftwareNameVerionGridQ91()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select ([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q9YesNo1],[Q9Remarks1]  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridViewQ91.DataSource = dt;
                GridViewQ91.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }





    protected void UpdateSoftwareNameVerionGridQ6()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q6YesNo],[Q6Remarks]   from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "' order by id asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                UpdateGridViewQ6.DataSource = dt;
                UpdateGridViewQ6.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void UpdateSoftwareNameVerionGridQ61()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q6YesNo1],[Q6Remarks1]  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "' order by id asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                UpdateGridViewQ61.DataSource = dt;
                UpdateGridViewQ61.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void UpdateSoftwareNameVerionGridQ9()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id, ([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q9YesNo],[Q9Remarks]   from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "' order by id asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                UpdateGridViewQ9.DataSource = dt;
                UpdateGridViewQ9.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void UpdateSoftwareNameVerionGridQ91()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q9YesNo1],[Q9Remarks1]  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "' order by id asc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                UpdateGridViewQ91.DataSource = dt;
                UpdateGridViewQ91.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }



    //updateing GridQ6
    protected void UpdateGridViewQ6_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        UpdateGridViewQ6.EditIndex = -1;
        this.UpdateSoftwareNameVerionGridQ6();
    }
    protected void UpdateGridViewQ6_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void UpdateGridViewQ6_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Label id = (Label)UpdateGridViewQ6.Rows[e.RowIndex].FindControl("id");
            TextBox Q6Remarks = (TextBox)UpdateGridViewQ6.Rows[e.RowIndex].FindControl("Q6Remarks") as TextBox;

            SqlCommand cmd = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurityGrid1] SET Q6Remarks = '" + Q6Remarks.Text + "'  WHERE EmailAddress = '" + txtEmail.Text + "'  and Id = '" + id.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            cmd.ExecuteNonQuery();
            UpdateGridViewQ6.EditIndex = -1;
            con.Close();

            UpdateSoftwareNameVerionGridQ6();
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }



    //updateing GridQ61
    protected void UpdateGridViewQ61_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void UpdateGridViewQ61_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        UpdateGridViewQ61.EditIndex = -1;
        this.UpdateSoftwareNameVerionGridQ61();
    }
    protected void UpdateGridViewQ61_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Label id = (Label)UpdateGridViewQ61.Rows[e.RowIndex].FindControl("id");
            TextBox Q6Remarks = (TextBox)UpdateGridViewQ61.Rows[e.RowIndex].FindControl("Q6Remarks1") as TextBox;

            SqlCommand cmd = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurityGrid2] SET Q6Remarks1 = '" + Q6Remarks.Text + "'  WHERE EmailAddress = '" + txtEmail.Text + "'  and Id = '" + id.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            cmd.ExecuteNonQuery();
            UpdateGridViewQ61.EditIndex = -1;
            con.Close();

            UpdateSoftwareNameVerionGridQ61();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }



    //updateing GridQ9
    protected void UpdateGridViewQ9_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        UpdateGridViewQ9.EditIndex = -1;
        this.UpdateSoftwareNameVerionGridQ9();
    }
    protected void UpdateGridViewQ9_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void UpdateGridViewQ9_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Label id = (Label)UpdateGridViewQ9.Rows[e.RowIndex].FindControl("id");
            TextBox Q9Remarks = (TextBox)UpdateGridViewQ9.Rows[e.RowIndex].FindControl("Q9Remarks") as TextBox;

            SqlCommand cmd = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurityGrid1] SET Q9Remarks = '" + Q9Remarks.Text + "'  WHERE EmailAddress = '" + txtEmail.Text + "'  and Id = '" + id.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            cmd.ExecuteNonQuery();
            UpdateGridViewQ9.EditIndex = -1;
            con.Close();

            UpdateSoftwareNameVerionGridQ9();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }



    //updateing GridQ9
    protected void UpdateGridViewQ91_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        UpdateGridViewQ91.EditIndex = -1;
        this.UpdateSoftwareNameVerionGridQ91();
    }
    protected void UpdateGridViewQ91_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
    protected void UpdateGridViewQ91_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Label id = (Label)UpdateGridViewQ91.Rows[e.RowIndex].FindControl("id");
            TextBox Q9Remarks = (TextBox)UpdateGridViewQ91.Rows[e.RowIndex].FindControl("Q9Remarks1") as TextBox;

            SqlCommand cmd = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurityGrid2] SET Q9Remarks1 = '" + Q9Remarks.Text + "'  WHERE EmailAddress = '" + txtEmail.Text + "'  and Id = '" + id.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            cmd.ExecuteNonQuery();
            UpdateGridViewQ91.EditIndex = -1;
            con.Close();

            UpdateSoftwareNameVerionGridQ91();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }
}

    

