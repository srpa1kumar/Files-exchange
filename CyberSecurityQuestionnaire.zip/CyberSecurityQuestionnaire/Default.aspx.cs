﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;
using System.IO;


public partial class Default4 : System.Web.UI.Page
{
    EncryptDecrypt objEncryptDecrypt = new EncryptDecrypt();
    int attempts; string TempPasscode;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["EmailID"] = username.Text;  //will redirect Emailid to Vendorpage
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //try
        //{
        //string Password = objEncryptDecrypt.Encrypt(password.Text.Trim(), true);
        Captcha1.ValidateCaptcha(txtCaptcha.Text.Trim());

        if (Captcha1.UserValidated)
        {

            attempts = Convert.ToInt32(ViewState["attempts"]);
            DataSet ds = new DataSet();
            DataSet ds1 = new DataSet();
           // using (SqlConnection con = new SqlConnection("Data Source=192.168.1.73;Initial Catalog=ITVendorLicences;User ID=axdev;password=ax@2019"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select AutoID,attemptcount from [LOGWITHUSER] where username=@username", con);
                cmd.Parameters.AddWithValue("@username", username.Text);
                // cmd.Parameters.AddWithValue("@password", Password);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds != null)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        attempts = Convert.ToInt32(ds.Tables[0].Rows[0]["attemptcount"]);
                        if (attempts == 3)
                        {
                            lblMsg.Text = "Your Account Already Locked";
                            lblMsg.ForeColor = Color.Red;
                        }
                        else
                        {
                            string EncryPassword = objEncryptDecrypt.Encrypt(password.Text.Trim(), true);
                            cmd = new SqlCommand("select AutoID,attemptcount from [LOGWITHUSER] where username=@username and password = '" + EncryPassword + "'", con);
                            cmd.Parameters.AddWithValue("@username", username.Text);
                            //cmd.Parameters.AddWithValue("@password", Password);
                            da = new SqlDataAdapter(cmd);
                            da.Fill(ds1);

                            if (ds1 != null)
                            {
                                if (ds1.Tables[0].Rows.Count > 0)
                                {
                                    ViewState["attempts"] = ds1.Tables[0].Rows[0]["attemptcount"];
                                    if (Convert.ToInt32(ViewState["attempts"]) != 3)
                                    {
                                        cmd = new SqlCommand("update [LOGWITHUSER] set attemptcount=0 where username=@username and password='" + EncryPassword + "'", con);
                                        cmd.Parameters.AddWithValue("@username", username.Text);
                                        //cmd.Parameters.AddWithValue("@password", password.Text);
                                        cmd.ExecuteNonQuery();


                                        SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
                                        SqlCommand cmd1 = new SqlCommand();
                                        cmd1.Connection = con1;
                                        cmd1.CommandText = string.Format("Select * from [LOGWITHUSER] where UserName = '{0}' and password = '{1}'and active = 1 ", username.Text.ToUpper(), EncryPassword.ToUpper());
                                        cmd1.Connection.Open();
                                        SqlDataReader dr = cmd1.ExecuteReader();


                                        if (dr.Read())
                                        {
                                            Session["Name"] = dr["Name"].ToString();
                                            Session["EmailId"] = dr["EmailId"].ToString();

                                            if (username.Text == "admin")
                                            {
                                                Response.Redirect("NewRegisterApproval.aspx");
                                            }

                                            LoadNExtPage();
                                            open();
                                            Label1.Visible = false;
                                        }


                                        else
                                        {
                                            Label1.Visible = true;
                                            Label2.Visible = true;
                                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Kindly register (or) Admin still not approve the registry!')", true);
                                        }
                                    }
                                    else
                                    {
                                        lblMsg.Text = "Your Account Already Locked...Contact Administrator";
                                        lblMsg.ForeColor = Color.Red;
                                    }
                                }
                                else
                                {
                                    string strquery = string.Empty;
                                    if (attempts > 2)
                                    {
                                        strquery = "update [LOGWITHUSER] set islocked=1, attemptcount=@attempts where username=@username and password='" + EncryPassword + "'";
                                        lblMsg.Text = "You Reached Maximum Attempts. Your account has been locked";
                                    }
                                    else
                                    {
                                        attempts = attempts + 1;
                                        ViewState["attempts"] = attempts;
                                        strquery = "update [LOGWITHUSER] set attemptcount=@attempts where username=@username";
                                        if (attempts == 3)
                                        {
                                            lblMsg.Text = "Your Account Locked";
                                        }
                                        else
                                            lblMsg.Text = "Your Password Wrong you have only " + (3 - attempts) + " attempts";
                                    }
                                    cmd = new SqlCommand(strquery, con);
                                    cmd.Parameters.AddWithValue("@username", username.Text);
                                    cmd.Parameters.AddWithValue("@password", password.Text);
                                    cmd.Parameters.AddWithValue("@attempts", attempts);
                                    cmd.ExecuteNonQuery();

                                    lblMsg.ForeColor = Color.Red;
                                }
                            }
                        }
                    }
                    else
                    {
                        lblMsg.Text = "UserName Not Exists";
                        lblMsg.ForeColor = Color.Red;
                    }
                }
                con.Close();
            }

        }

        else
        {
            Label5.Visible = true;
            Label5.Text = "Invalid. Please try again.";
        }
        //}

        //catch (Exception ex)
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        //}
    }


    protected void LoadNExtPage()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);

            SqlCommand cdm = new SqlCommand("select distinct dept from  LOGWITHUSER where UserName ='" + username.Text + "'", con);
            SqlDataAdapter dr = new SqlDataAdapter(cdm);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            if (dt.Rows.Count > 0)
            {

            }
        }
        catch
        {
        }
    }

    protected void open()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);

        SqlCommand cdm = new SqlCommand("select [EmailAddress]  FROM [ITVendorLicences].[dbo].[VendorCyberSecurity] where [EmailAddress] = '" + username.Text + "'", con);
        SqlDataAdapter dr = new SqlDataAdapter(cdm);
        DataTable dt = new DataTable();
        dr.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Response.Redirect("Edit_VendorCyberSecurityQuestionnaire.aspx");
        }

        else
        {
            Response.Redirect("VendorCyberSecurityQuestionnaire.aspx");
        }
    }



    protected void LinkButton1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("NewRegister.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Response.Redirect("ResetPassword.aspx");

        pnlpopup.Visible = true;
        txtUsername.Text = null;
        this.MSG.Show();
    }

    protected void MailMessage()
    {
        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");

        ////---------------------Test Email ID------------------------------
        msg.To.Add(txtUsername.Text);
        //msg.CC.Add("Jaganathan.k@indo-mim.com");
        msg.CC.Add("shalini.r@indo-mim.com");


        msg.Subject = "Account Activation";
        string body = "Hello " + txtUsername.Text.Trim() + ",";
        body += "<br /><br />Please click the following link to Reset your account password";
        //body += "<br /><a href  LINK:= '" + Request.Url.AbsoluteUri.Replace("ResetPassword.aspx", "ResetPassword.aspx?") + "'>Click here to activate your account.</a>";
        body += "<br /> LINK: <a href='http://192.168.1.73/demopage/ResetPassword.aspx'>http://192.168.1.73/demopage/ResetPassword.aspx</a></b><br/><br/>";
        body += "<table style='width:450px'><tr><td></td></tr><tr><td></td> </tr> <tr><td><table border='1' style='border: thin solid #C0C0C0; width: 450px;  font-family: Calibri;'><tr> <td>UserName</td><td>" + Convert.ToString(txtUsername.Text) + "</td></tr> <tr><td>Temporary Password</td><td> " + TempPasscode.ToString() + "</td> </tr> </tr> <tr><td></td><td> </tr> </table>" + "<br/>";
        body += "<br /><br />Thanks";
        msg.Body = body;
        msg.IsBodyHtml = true;

        // msg.Subject = "TEST MAIL.PLZ,IGNORE IT";

        msg.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();

        //***** Old Host ID ******
        //smtp.Host = "192.168.1.25";

        //***** New Host ID ******
        smtp.Host = "192.168.1.71";
        smtp.Port = 25;
        smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        try
        {
            smtp.Send(msg);
        }
        catch
        {
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        insertTempass();
    }

    public static string CreateRandomPassword(int PasswordLength)
    {
        string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
        Random randNum = new Random();
        char[] chars = new char[PasswordLength];
        int allowedCharCount = _allowedChars.Length;
        for (int i = 0; i < PasswordLength; i++)
        {
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }

    protected void insertTempass()
    {

        SqlCommand cdm = new SqlCommand(" select * FROM [ITVendorLicences].[dbo].[LOGWITHUSER] where status = 'Approved' and EmailId='" + txtUsername.Text + "' ", con);
        SqlDataAdapter dr = new SqlDataAdapter(cdm);
        DataTable dt = new DataTable();
        dr.Fill(dt);
        if (dt.Rows.Count == 0)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Your Registration is still not approved. Kindly check after approval!')", true);
        }
        else
        {

            TempPasscode = CreateRandomPassword(8);
            con.Open();
            string strsqlcommand1 = "update LOGWITHUSER set Password = @Password where EmailId='" + txtUsername.Text + "'";
            SqlCommand cmd1 = new SqlCommand(strsqlcommand1, con);
            cmd1.Parameters.Add("@Password", SqlDbType.VarChar).Value = objEncryptDecrypt.Encrypt(TempPasscode.ToString(), true);
            int roweffected = cmd1.ExecuteNonQuery();
            con.Close();
            MailMessage();
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Activation/Reset email has been sent. Kindly check in your entered MailiD!')", true);
        }
    }
}