﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;
using System.IO;

public partial class CyberSecurityQuestionnaire : System.Web.UI.Page
{
    string Name; string EmailID; string date; string ID;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["Name"] == null)
            {
                Response.Redirect("default.aspx");

            }

            SetInitialRow();
            //SetInitialRow1();
            EmailID = Session["EmailID"].ToString(); // value of EmailIDTextBox;
            Name = Session["Name"].ToString();
            date = System.DateTime.Now.ToString("dd-MMM-yy");
            txtdate.Text = System.DateTime.Now.ToString("dd-MMM-yy");
            loadGrid();
        }
    }

    private void SetInitialRow()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));
        dt.Columns.Add(new DataColumn("Column3", typeof(string)));
        dt.Columns.Add(new DataColumn("Column4", typeof(string)));
        dt.Columns.Add(new DataColumn("Column5", typeof(string)));
        dt.Columns.Add(new DataColumn("Column6", typeof(string)));
        dt.Columns.Add(new DataColumn("Column7", typeof(string)));
        dr = dt.NewRow();
        dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dr["Column3"] = string.Empty;
        dr["Column4"] = string.Empty;
        dr["Column5"] = string.Empty;
        dr["Column6"] = string.Empty;
        dr["Column7"] = string.Empty;
        dt.Rows.Add(dr);

        //Store the DataTable in ViewState
        ViewState["CurrentTable"] = dt;

        Gridview1.DataSource = dt;
        Gridview1.DataBind();
    }

    private void SetInitialRow1()
    {
        DataTable dt1 = new DataTable();
        DataRow dr1 = null;
        dt1.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column2", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column3", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column4", typeof(string)));
        dt1.Columns.Add(new DataColumn("Column5", typeof(string)));
        dr1 = dt1.NewRow();
        dr1["RowNumber"] = 1;
        dr1["Column1"] = string.Empty;
        dr1["Column2"] = string.Empty;
        dr1["Column3"] = string.Empty;
        dr1["Column4"] = string.Empty;
        dr1["Column5"] = string.Empty;
        dt1.Rows.Add(dr1);

        //Store the DataTable in ViewState
        ViewState["CurrentTable1"] = dt1;

        Gridview2.DataSource = dt1;
        Gridview2.DataBind();
    }

    private void AddNewRowToGrid()
    {
        int rowIndex = 0;

        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    //extract the TextBox values
                    TextBox box1 = (TextBox)Gridview1.Rows[rowIndex].Cells[1].FindControl("SoftwareName");
                    TextBox box2 = (TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("Version");
                    TextBox box3 = (TextBox)Gridview1.Rows[rowIndex].Cells[3].FindControl("Description");
                    DropDownList box4 = (DropDownList)Gridview1.Rows[rowIndex].Cells[4].FindControl("License");
                    DropDownList box5 = (DropDownList)Gridview1.Rows[rowIndex].Cells[5].FindControl("ddlLicense1");
                    TextBox box6 = (TextBox)Gridview1.Rows[rowIndex].Cells[6].FindControl("ValidFrom");
                    TextBox box7 = (TextBox)Gridview1.Rows[rowIndex].Cells[7].FindControl("ValidTill");

                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["Column1"] = box1.Text;
                    dtCurrentTable.Rows[i - 1]["Column2"] = box2.Text;
                    dtCurrentTable.Rows[i - 1]["Column3"] = box3.Text;
                    dtCurrentTable.Rows[i - 1]["Column4"] = box4.Text;
                    dtCurrentTable.Rows[i - 1]["Column5"] = box5.Text;
                    dtCurrentTable.Rows[i - 1]["Column6"] = box6.Text;
                    dtCurrentTable.Rows[i - 1]["Column7"] = box7.Text;

                    rowIndex++;
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable"] = dtCurrentTable;

                Gridview1.DataSource = dtCurrentTable;
                Gridview1.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }

    private void AddNewRowToGrid1()
    {

        int rowIndex = 0;

        if (ViewState["CurrentTable1"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    //extract the TextBox values
                    TextBox box1 = (TextBox)Gridview2.Rows[rowIndex].Cells[1].FindControl("SoftwareName1");
                    TextBox box2 = (TextBox)Gridview2.Rows[rowIndex].Cells[2].FindControl("Version1");
                    TextBox box3 = (TextBox)Gridview2.Rows[rowIndex].Cells[3].FindControl("SoftwareVendorName1");
                    TextBox box4 = (TextBox)Gridview2.Rows[rowIndex].Cells[4].FindControl("License1");
                    TextBox box5 = (TextBox)Gridview2.Rows[rowIndex].Cells[5].FindControl("LicenseDistribution1");

                    drCurrentRow = dtCurrentTable.NewRow();
                    drCurrentRow["RowNumber"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["Column1"] = box1.Text;
                    dtCurrentTable.Rows[i - 1]["Column2"] = box2.Text;
                    dtCurrentTable.Rows[i - 1]["Column3"] = box3.Text;
                    dtCurrentTable.Rows[i - 1]["Column4"] = box4.Text;
                    dtCurrentTable.Rows[i - 1]["Column5"] = box5.Text;

                    rowIndex++;
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable1"] = dtCurrentTable;

                Gridview2.DataSource = dtCurrentTable;
                Gridview2.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }

        //Set Previous Data on Postbacks
        SetPreviousData1();
    }



    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)Gridview1.Rows[rowIndex].Cells[1].FindControl("SoftwareName");
                    TextBox box2 = (TextBox)Gridview1.Rows[rowIndex].Cells[2].FindControl("Version");
                    TextBox box3 = (TextBox)Gridview1.Rows[rowIndex].Cells[3].FindControl("Description");
                    DropDownList box4 = (DropDownList)Gridview1.Rows[rowIndex].Cells[4].FindControl("License");
                    DropDownList box5 = (DropDownList)Gridview1.Rows[rowIndex].Cells[5].FindControl("ddlLicense1");
                    TextBox box6 = (TextBox)Gridview1.Rows[rowIndex].Cells[6].FindControl("ValidFrom");
                    TextBox box7 = (TextBox)Gridview1.Rows[rowIndex].Cells[7].FindControl("ValidTill");

                    box1.Text = dt.Rows[i]["Column1"].ToString();
                    box2.Text = dt.Rows[i]["Column2"].ToString();
                    box3.Text = dt.Rows[i]["Column3"].ToString();
                    box4.Text = dt.Rows[i]["Column4"].ToString();
                    box5.Text = dt.Rows[i]["Column5"].ToString();
                    box6.Text = dt.Rows[i]["Column6"].ToString();
                    box7.Text = dt.Rows[i]["Column7"].ToString();

                    rowIndex++;
                }
            }
        }
    }

    private void SetPreviousData1()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable1"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Label box1 = (Label)Gridview2.Rows[rowIndex].Cells[1].FindControl("SoftwareName1");
                    Label box2 = (Label)Gridview2.Rows[rowIndex].Cells[2].FindControl("Version1");
                    Label box3 = (Label)Gridview2.Rows[rowIndex].Cells[3].FindControl("SoftwareVendorName1");
                    TextBox box4 = (TextBox)Gridview2.Rows[rowIndex].Cells[4].FindControl("License1");
                    TextBox box5 = (TextBox)Gridview2.Rows[rowIndex].Cells[5].FindControl("LicenseDistribution1");

                    box1.Text = dt.Rows[i]["Column1"].ToString();
                    box2.Text = dt.Rows[i]["Column2"].ToString();
                    box3.Text = dt.Rows[i]["Column3"].ToString();
                    box4.Text = dt.Rows[i]["Column4"].ToString();
                    box5.Text = dt.Rows[i]["Column5"].ToString();

                    rowIndex++;
                }
            }
        }
    }



    protected void loadGrid()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@" Select * from [LOGWITHUSER] where EmailId = '" + EmailID + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                txtSupCompNme.Text = Convert.ToString(dt.Rows[0]["SupplierCompanyName"]);
                txtName.Text = Convert.ToString(dt.Rows[0]["Name"]);
                txtEmail.Text = Convert.ToString(dt.Rows[0]["EmailId"]);
                txtphone.Text = Convert.ToInt64(dt.Rows[0]["Phone"]).ToString();
            }
        }
        catch
        {

        }
        con.Close();
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }
    protected void ButtonAdd0_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid1();
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            foreach (GridViewRow row1 in Gridview1.Rows)
            {

                DropDownList License = (DropDownList)row1.FindControl("License");
                DropDownList LicenseSubscriptionModel = (DropDownList)row1.FindControl("ddlLicense1");
                TextBox ValidFrom = (TextBox)row1.FindControl("ValidFrom");
                TextBox ValidTill = (TextBox)row1.FindControl("ValidTill");



                if (LicenseSubscriptionModel.SelectedItem.Text == "YES" && ValidFrom.Text == "" && ValidTill.Text == "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Mandate to fill Valid From and Till Date!, Click OK');", true);
                    ValidFrom.BackColor = Color.LightCoral;
                    ValidTill.BackColor = Color.LightCoral;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(@"select * from VendorCyberSecurity where EmailAddress = '" + txtEmail.Text + "'", con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        UpdateSave();
                        ScriptManager.RegisterStartupScript(this, this.GetType(),
                 "alert",
                 "alert('Data Updated and Mail sent to concern person Successfully, Click OK');window.location ='VendorCyberSec2.aspx';", true);

                    }
                    else
                    {
                        Save();
                        ScriptManager.RegisterStartupScript(this, this.GetType(),
                 "alert",
                 "alert('Data Saved Successfully, Click OK');window.location ='VendorCyberSec2.aspx';", true);

                    }

                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }


    protected void Save()
    {
        SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[VendorCyberSecurity]([SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber]
           ,[Q7Name],[Q7Designation],[Q7EmailAddress],[Q7PhoneNumber],[Q7Name1],[Q7Designation1],[Q7EmailAddress1],[Q7PhoneNumber1],Date)
     VALUES
           ('" + txtSupCompNme.Text + "','" + txtName.Text + "','" + txtEmail.Text + "','" + txtphone.Text + @"',
'" + txtQ7Nme.Text + "','" + txtQ7desg.Text + "','" + txtQ7email.Text + "','" + txtQ7Phno.Text + "','" + txtQ7Nme1.Text + "','" + txtQ7desg1.Text + "','" + txtQ7email1.Text + @"',
        '" + txtQ7Phno1.Text + "','" + txtdate.Text + "')", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }

    protected void SaveGrid1()
    {
        //try
        //{
        foreach (GridViewRow row in Gridview1.Rows)
        {

            TextBox SoftwareName = (TextBox)row.FindControl("SoftwareName");
            TextBox Version = (TextBox)row.FindControl("Version");
            TextBox Description = (TextBox)row.FindControl("Description");
            DropDownList License = (DropDownList)row.FindControl("License");
            DropDownList LicenseSubscriptionModel = (DropDownList)row.FindControl("ddlLicense1");
            TextBox ValidFrom = (TextBox)row.FindControl("ValidFrom");
            TextBox ValidTill = (TextBox)row.FindControl("ValidTill");



            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[VendorCyberSecurityGrid1]([SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],
[T1SoftwareName],[T1Version],[T1Description],[T1LicenseType],[T1LicenseSubscriptionModel],[T1ValidFrom],[T1ValidTill],[Date])
             VALUES
                   ('" + txtSupCompNme.Text + "','" + txtName.Text + "','" + txtEmail.Text + "','" + txtphone.Text + "','" + SoftwareName.Text + "','" + Version.Text + @"',
                    '" + Description.Text + "','" + License.SelectedItem.Text + "','" + LicenseSubscriptionModel.SelectedItem.Text + "','" + ValidFrom.Text + "','" + ValidTill.Text + "','" + txtdate.Text + "')", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        //}
        //catch (Exception ex)
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        //    Panel2.Visible = false;
        //}
    }

    protected void SaveGrid2()
    {
        //try
        //{

        foreach (GridViewRow row1 in Gridview2.Rows)
        {
            //TextBox SoftwareName1 = (TextBox)row1.FindControl("SoftwareName1");
            //TextBox Version1 = (TextBox)row1.FindControl("Version1");
            //TextBox SoftwareVendorName1 = (TextBox)row1.FindControl("SoftwareVendorName1");
            TextBox License1 = (TextBox)row1.FindControl("License1");
            TextBox LicenseDistribution1 = (TextBox)row1.FindControl("LicenseDistribution1");


            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[VendorCyberSecurityGrid2]([SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],
        [T2SoftwareName],[T2Version],[T2SoftwareVendorName],[T2LicenseUsageModel],[T2LicenseDistribution],Date)
             VALUES
                   ('" + txtSupCompNme.Text + "','" + txtName.Text + "','" + txtEmail.Text + "','" + txtphone.Text + "',@SoftwareName1,@Version1,@SoftwareVendorName1,'" + License1.Text + "','" + LicenseDistribution1.Text + "','" + txtdate.Text + "')", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            cmd.Parameters.AddWithValue("@SoftwareName1", row1.Cells[0].Text);
            cmd.Parameters.AddWithValue("@Version1", row1.Cells[1].Text);
            cmd.Parameters.AddWithValue("@SoftwareVendorName1", row1.Cells[2].Text);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        //}
        //catch (Exception ex)
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        //    Panel2.Visible = false;
        //}
    }


    protected void UpdateSave()
    {
        SqlCommand cmd1 = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurity] SET [Q7Name] = '" + txtQ7Nme.Text + "',[Q7Designation] = '" + txtQ7desg.Text + @"',
[Q7EmailAddress] = '" + txtQ7email.Text + "',[Q7PhoneNumber] = '" + txtQ7Phno.Text + "',[Q7Name1] = '" + txtQ7Nme1.Text + "',[Q7Designation1] = '" + txtQ7desg1.Text + "',[Q7EmailAddress1] = '" + txtQ7email1.Text + @"' 
,[Q7PhoneNumber1] = '" + txtQ7Phno1.Text + "' WHERE [EmailAddress] = '" + txtEmail.Text + "'", con);
        SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
        DataTable dt1 = new DataTable();
        con.Open();
        cmd1.ExecuteNonQuery();
        con.Close();
    }


    protected void UpdateGrid1()
    {

        foreach (GridViewRow row in Gridview1.Rows)
        {

            SqlCommand cmd1 = new SqlCommand(@"select * from [VendorCyberSecurityGrid1] where EmailAddress = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {

                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    ID = Convert.ToString(dt1.Rows[i]["Id"]);

                    DropDownList License = (DropDownList)row.FindControl("License");
                    DropDownList LicenseSubscriptionModel = (DropDownList)row.FindControl("ddlLicense1");

                    if (LicenseSubscriptionModel.SelectedItem.Text == "--Select--")
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly Fill LicenseSubscriptionModel Type in Q5(T1)!, Click OK');", true);
                    }

                    if (License.SelectedItem.Text == "--Select--")
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly Select dropdown of License Type in Q5(T1)!, Click OK');", true);
                    }
                    else
                    {


                        TextBox SoftwareName = (TextBox)row.FindControl("SoftwareName");
                        TextBox Version = (TextBox)row.FindControl("Version");
                        TextBox Description = (TextBox)row.FindControl("Description");
                        //DropDownList License = (DropDownList)row.FindControl("License");
                        //DropDownList LicenseSubscriptionModel = (DropDownList)row.FindControl("ddlLicense1");
                        TextBox ValidFrom = (TextBox)row.FindControl("ValidFrom");
                        TextBox ValidTill = (TextBox)row.FindControl("ValidTill");


                        SqlCommand cmd = new SqlCommand(@"UPDATE [dbo].[VendorCyberSecurityGrid1]
   SET [T1SoftwareName] = '" + SoftwareName.Text + "',[T1Version] = '" + Version.Text + "',[T1Description] =  '" + Description.Text + "',[T1LicenseType] = '" + License.SelectedItem.Text + @"'
      ,[T1LicenseSubscriptionModel] = '" + LicenseSubscriptionModel.SelectedItem.Text + "',[T1ValidFrom] = '" + ValidFrom.Text + "',[T1ValidTill] = '" + ValidTill.Text + @"'
 WHERE EmailAddress = '" + txtEmail.Text + "' and ID = '" + ID + "'", con);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }

                }
            }
        }
    }




    protected void UpdateGrid2()
    {

        foreach (GridViewRow row1 in Gridview2.Rows)
        {
            SqlCommand cmd1 = new SqlCommand(@"select * from [VendorCyberSecurityGrid1] where EmailAddress = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    ID = Convert.ToString(dt1.Rows[i]["Id"]);

                    TextBox License1 = (TextBox)row1.FindControl("License1");
                    TextBox LicenseDistribution1 = (TextBox)row1.FindControl("LicenseDistribution1");

                    SqlCommand cmd = new SqlCommand(@" UPDATE [dbo].[VendorCyberSecurityGrid2] SET [T2SoftwareName] =  @SoftwareName1, [T2Version] = @Version1
      ,[T2SoftwareVendorName] = @SoftwareVendorName1,[T2LicenseUsageModel] = '" + License1.Text + "',[T2LicenseDistribution] = '" + LicenseDistribution1.Text + @"'
       WHERE EmailAddress = '" + txtEmail.Text + "' and ID = '" + ID + "'", con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    con.Open();
                    cmd.Parameters.AddWithValue("@SoftwareName1", row1.Cells[0].Text);
                    cmd.Parameters.AddWithValue("@Version1", row1.Cells[1].Text);
                    cmd.Parameters.AddWithValue("@SoftwareVendorName1", row1.Cells[2].Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
    }


    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex + 1;

        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex < dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data
                    dt.Rows.Remove(dt.Rows[rowID]);
                }
            }

            //Store the current data in ViewState for future reference

            ViewState["CurrentTable"] = dt;

            //Re bind the GridView for the updated data

            Gridview1.DataSource = dt;
            Gridview1.DataBind();
        }
        //Set Previous Data on Postbacks
        SetPreviousData();
    }


    protected void Gridview1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            DataTable dt = (DataTable)ViewState["CurrentTable"];
            LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");

            if (lb != null)
            {
                if (dt.Rows.Count > 1)
                {
                    if (e.Row.RowIndex == dt.Rows.Count - 1)
                    {
                        lb.Visible = false;
                    }
                }
                else
                {
                    lb.Visible = false;
                }
            }
        }
    }



    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex + 1;

        if (ViewState["CurrentTable1"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable1"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex < dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data
                    dt.Rows.Remove(dt.Rows[rowID]);
                }
            }

            //Store the current data in ViewState for future reference

            ViewState["CurrentTable1"] = dt;

            //Re bind the GridView for the updated data

            Gridview2.DataSource = dt;
            Gridview2.DataBind();
        }
        //Set Previous Data on Postbacks
        SetPreviousData1();
    }


    protected void Gridview2_RowCreated(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{

        //    DataTable dt = (DataTable)ViewState["CurrentTable1"];
        //    LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton2");

        //    if (lb != null)
        //    {
        //        if (dt.Rows.Count > 1)
        //        {
        //            if (e.Row.RowIndex == dt.Rows.Count - 1)
        //            {
        //                lb.Visible = false;
        //            }
        //        }
        //        else
        //        {
        //            lb.Visible = false;
        //        }
        //    }
        //}
    }

    protected void ddlLicense1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Upload(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            foreach (HttpPostedFile postedFile in FileUpload1.PostedFiles)
            {
                string filename = Path.GetFileName(postedFile.FileName);
                string contentType = postedFile.ContentType;
                using (Stream fs = postedFile.InputStream)
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        string constr = ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString;
                        using (SqlConnection con = new SqlConnection(constr))
                        {
                            string query = "INSERT INTO [dbo].[VendorCyberFileUpload]([SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[ContentName],[ContentType],[Content]) VALUES (@SupplierCompanyName,@Name,@EmailAddress,@PhoneNumber,@ContentName,@ContentType,@Content)";
                            using (SqlCommand cmd = new SqlCommand(query))
                            {
                                cmd.Connection = con;
                                cmd.Parameters.AddWithValue("@SupplierCompanyName", txtSupCompNme.Text);
                                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                                cmd.Parameters.AddWithValue("@EmailAddress", txtEmail.Text);
                                cmd.Parameters.AddWithValue("@PhoneNumber", txtphone.Text);

                                cmd.Parameters.AddWithValue("@ContentName", filename);
                                cmd.Parameters.AddWithValue("@ContentType", contentType);
                                cmd.Parameters.AddWithValue("@Content", bytes);
                                con.Open();
                                cmd.ExecuteNonQuery();
                                con.Close();
                                Label1.Visible = true;
                                Label1.Text = "File uploaded Successfully.";
                            }
                        }
                    }
                }
            }
        }
        else
        {
            Label1.Visible = true;
            Label1.Text = "No File Uploaded.";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            Panel2.Visible = true;

            //foreach (GridViewRow row1 in Gridview1.Rows)
            //{

            //    DropDownList License = (DropDownList)row1.FindControl("License");
            //    DropDownList LicenseSubscriptionModel = (DropDownList)row1.FindControl("ddlLicense1");
            //    TextBox ValidFrom = (TextBox)row1.FindControl("ValidFrom");
            //    TextBox ValidTill = (TextBox)row1.FindControl("ValidTill");

            //    if (LicenseSubscriptionModel.SelectedItem.Text == "--Select--")
            //    {
            //        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly Fill LicenseSubscriptionModel Type in Q5(T1)!, Click OK');", true);
            //    }

            //    if (License.SelectedItem.Text == "--Select--")
            //    {
            //        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly Select dropdown of License Type in Q5(T1)!, Click OK');", true);
            //    }


            //    else
            //    {
            SqlCommand cmd = new SqlCommand(@"select * from [VendorCyberSecurityGrid1] where EmailAddress = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                //UpdateGrid1();
                //UpdateGrid2();
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Data Updated and Mail sent to concern person Successfully, Click OK');", true);

            }
            else
            {
                SaveGrid1();
                SaveGrid2();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Data Saved Successfully, Click OK');", true);
                Button1.Visible = false;
                SoftwareNameVerionGrid();
                SoftwareNameVerionGrid2();
            }

            //    }
            //}


        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
            Panel2.Visible = false;
        }
    }


    protected void License_SelectedIndexChanged(object sender, EventArgs e)
    {

        DataTable dt = new DataTable();
        dt.Columns.AddRange(new DataColumn[5] { new DataColumn("SoftwareName1"), new DataColumn("Version1"), new DataColumn("SoftwareVendorName1"), new DataColumn("License1"), new DataColumn("LicenseDistribution1") });
        foreach (GridViewRow row in Gridview1.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
                DropDownList licenceType = (row.Cells[0].FindControl("License") as DropDownList);

                if (licenceType.SelectedItem.Text == "Licensed")
                {
                    Gridview2.Visible = true;


                    //string RowNumber = (row.Cells[1].FindControl("RowNumber") as TextBox).Text;
                    string SoftwareName1 = (row.Cells[2].FindControl("SoftwareName") as TextBox).Text;
                    string Version1 = (row.Cells[3].FindControl("Version") as TextBox).Text;
                    string SoftwareVendorName1 = (row.Cells[4].FindControl("Description") as TextBox).Text;
                    string License1 = "";
                    string LicenseDistribution1 = "";

                    dt.Rows.Add(SoftwareName1, Version1, SoftwareVendorName1, License1, LicenseDistribution1);

                }
                if (licenceType.SelectedItem.Text == "Home Grown")
                {
                    Gridview2.Visible = true;

                    //string RowNumber = (row.Cells[1].FindControl("RowNumber") as TextBox).Text;
                    string SoftwareName1 = (row.Cells[2].FindControl("SoftwareName") as TextBox).Text;
                    string Version1 = (row.Cells[3].FindControl("Version") as TextBox).Text;
                    string SoftwareVendorName1 = (row.Cells[4].FindControl("Description") as TextBox).Text;
                    string License1 = "";
                    string LicenseDistribution1 = "";

                    dt.Rows.Add(SoftwareName1, Version1, SoftwareVendorName1, License1, LicenseDistribution1);
                }
            }
        }

        ViewState["dt"] = dt;
        BindGrid();


    }

    protected void BindGrid()
    {
        Gridview2.DataSource = ViewState["dt"] as DataTable;
        Gridview2.DataBind();

        //Gridview2.DataSource = dt;
        //Gridview2.DataBind();

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            Button2.Visible = false;
            grid3update();
            grid3update2();

        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
            Panel3.Visible = false;
        }
    }


    protected void SoftwareNameVerionGrid()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q6Remarks] as Remarks  from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView3.DataSource = dt;
                GridView3.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }


    protected void grid3update()
    {

        int totalRows = GridView3.Rows.Count;
        for (int RowIndex = 0; RowIndex < totalRows; RowIndex++)
        // foreach (GridViewRow gvr in GridView3.Rows)
        {
            GridViewRow row = GridView3.Rows[RowIndex];
            Label id = row.FindControl("id") as Label;
            DropDownList YesNo = row.FindControl("ddlyesno") as DropDownList;
            TextBox Remarks = row.FindControl("Remarks") as TextBox;
            // TextBox Remarks = (TextBox)row.FindControl("Remarks");

            if (YesNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly selet Yes/No!, Click OK');", true);
                Panel3.Visible = false;
            }
            if (YesNo.SelectedItem.Text != "--Select--")
            {
                Panel3.Visible = true;
                SqlCommand cmd = new SqlCommand("UPDATE [VendorCyberSecurityGrid1] SET Q6YesNo = @Q6YesNo,Q6Remarks = @Q6Remarks WHERE id = @id", con);
                cmd.Parameters.AddWithValue("@Q6YesNo", YesNo.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@Q6Remarks", Remarks.Text);
                cmd.Parameters.AddWithValue("@id", id.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        // Response.Redirect(Request.Url.AbsoluteUri);
    }



    protected void SoftwareNameVerionGrid2()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q6Remarks1] as Remarks  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView4.DataSource = dt;
                GridView4.DataBind();
            }
        }
        catch
        {

        }
        con.Close();
    }

    protected void grid3update2()
    {
        int totalRows = GridView4.Rows.Count;
        for (int RowIndex = 0; RowIndex < totalRows; RowIndex++)
        // foreach (GridViewRow gvr in GridView3.Rows)
        {
            GridViewRow row = GridView4.Rows[RowIndex];
            Label id = row.FindControl("id") as Label;
            DropDownList YesNo = row.FindControl("ddlyesno") as DropDownList;
            TextBox Remarks = row.FindControl("Remarks") as TextBox;
            // TextBox Remarks = (TextBox)row.FindControl("Remarks");

            if (YesNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly selet Yes/No!, Click OK');", true);
                Panel3.Visible = false;
            }
            if (YesNo.SelectedItem.Text != "--Select--")
            {
                Panel3.Visible = true;
                SqlCommand cmd = new SqlCommand("UPDATE [VendorCyberSecurityGrid2] SET Q6YesNo1 = @Q6YesNo,Q6Remarks1 = @Q6Remarks WHERE id = @id", con);
                cmd.Parameters.AddWithValue("@Q6YesNo", YesNo.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@Q6Remarks", Remarks.Text);
                cmd.Parameters.AddWithValue("@id", id.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }
   


    protected void Gridview2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string item = e.Row.Cells[0].Text;
            foreach (Button button in e.Row.Cells[2].Controls.OfType<Button>())
            {
                if (button.CommandName == "Delete")
                {
                    button.Attributes["onclick"] = "if(!confirm('Do you want to delete " + item + "?')){ return false; };";
                }
            }
        }
    }



    protected void Gridview2_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int index = Convert.ToInt32(e.RowIndex);
        DataTable dt = ViewState["dt"] as DataTable;
        dt.Rows[index].Delete();
        ViewState["dt"] = dt;
        Gridview2.DataSource = dt;
        Gridview2.DataBind();
    }

}



    

