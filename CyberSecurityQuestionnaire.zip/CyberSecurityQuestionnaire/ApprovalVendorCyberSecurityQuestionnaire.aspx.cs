﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;
using System.IO;

public partial class CyberSecurityQuestionnaire : System.Web.UI.Page
{
    string Name; string EmailID;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string s = Request.QueryString["DOC"];
            EmailID = s.ToString();
        }

        loadGrid();
        grid1();
        grid2();
        loadGrid1();
        DownloadFile();
        SoftwareNameVerionGridQ6();
        SoftwareNameVerionGridQ61();
        SoftwareNameVerionGridQ9();
        SoftwareNameVerionGridQ91();
    }

    private void grid1()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@"  select ROW_NUMBER() OVER(ORDER BY date asc) AS ID,[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[T1SoftwareName],[T1Version],
  [T1Description],[T1LicenseType],[T1LicenseSubscriptionModel],CONVERT(varchar,T1ValidFrom,1)[T1ValidFrom],CONVERT(varchar,T1ValidTill,1)[T1ValidTill] from [ITVendorLicences].[dbo].[VendorCyberSecurityGrid1]
  where [EmailAddress] = '" + EmailID + "' order by id desc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            Gridview1.DataSource = dt;
            Gridview1.DataBind();
        }
    }

    private void grid2()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@"  SELECT  ROW_NUMBER() OVER(ORDER BY date asc) AS ID,[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[T2SoftwareName],[T2Version],[T2SoftwareVendorName]
      ,[T2LicenseUsageModel],[T2LicenseDistribution],CONVERT(varchar,Date,1)[Date] FROM [ITVendorLicences].[dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + EmailID + "' order by id desc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            Gridview2.DataSource = dt;
            Gridview2.DataBind();
        }
    }


    private void DownloadFile()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@" select id, [ContentName] ,[ContentType],[Content]from [ITVendorLicences].[dbo].[VendorCyberFileUpload] where [EmailAddress] = '" + EmailID + "' ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            GridView3.DataSource = dt;
            GridView3.DataBind();
        }
    }


    protected void loadGrid()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@" Select * from [LOGWITHUSER] where EmailId = '" + EmailID + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                txtSupCompNme.Text = Convert.ToString(dt.Rows[0]["SupplierCompanyName"]);
                txtName.Text = Convert.ToString(dt.Rows[0]["Name"]);
                txtEmail.Text = Convert.ToString(dt.Rows[0]["EmailId"]);
                txtphone.Text = Convert.ToInt64(dt.Rows[0]["Phone"]).ToString();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }


    protected void loadGrid1()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"SELECT  [Id],[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[Q7Name],[Q7Designation]
,[Q7EmailAddress],[Q7PhoneNumber],[Q7Name1],[Q7Designation1],[Q7EmailAddress1],[Q7PhoneNumber1],[Q8YesOrNo],[Q9YesOrNo],[Q9Remarks1]
,[Q9Remarks2],[Q10YesOrNo],[Q10mitigation],[FormFilledByName],[FormFilledByDesignation],[FormFilledByDateOfSubmission],[Status]
  FROM [ITVendorLicences].[dbo].[VendorCyberSecurity] where [EmailAddress] = '" + EmailID + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {

                txtQ7Nme.Text = Convert.ToString(dt.Rows[0]["Q7Name"]).ToString();
                txtQ7desg.Text = Convert.ToString(dt.Rows[0]["Q7Designation"]);
                txtQ7email.Text = Convert.ToString(dt.Rows[0]["Q7EmailAddress"]);
                txtQ7Phno.Text = Convert.ToInt64(dt.Rows[0]["Q7PhoneNumber"]).ToString();

                txtQ7Nme1.Text = Convert.ToString(dt.Rows[0]["Q7Name1"]).ToString();
                txtQ7desg1.Text = Convert.ToString(dt.Rows[0]["Q7Designation1"]);
                txtQ7email1.Text = Convert.ToString(dt.Rows[0]["Q7EmailAddress1"]);
                txtQ7Phno1.Text = Convert.ToInt64(dt.Rows[0]["Q7PhoneNumber1"]).ToString();

                lblQ8.Text = Convert.ToString(dt.Rows[0]["Q8YesOrNo"]);

                lblQ10.Text = Convert.ToString(dt.Rows[0]["Q10YesOrNo"]);
                lblQ11.Text = Convert.ToString(dt.Rows[0]["Q10mitigation"]);
                txtFormName.Text = Convert.ToString(dt.Rows[0]["FormFilledByName"]);
                txtFormDesg.Text = Convert.ToString(dt.Rows[0]["FormFilledByDesignation"]).ToString();
                txtformDate.Text = Convert.ToDateTime(dt.Rows[0]["FormFilledByDateOfSubmission"]).ToString();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        byte[] documentBinary;
        GridViewRow gvr = ((Button)sender).Parent.Parent as GridViewRow;
        Label ID = (Label)gvr.FindControl("ID");
        string filename = string.Empty;
        con.Open();
        SqlCommand com = new SqlCommand(" select id, [ContentName] ,[ContentType],[Content]from [ITVendorLicences].[dbo].[VendorCyberFileUpload] where [EmailAddress] = '" + txtEmail.Text + "' and id = '" + ID.Text + "' ", con);

        try
        {
            using (SqlDataReader sdr = com.ExecuteReader())
            {
                sdr.Read();
                // bytes = (byte[])sdr["fileattachment"];
                documentBinary = (byte[])sdr["Content"];

                filename = sdr["ContentName"].ToString();
            }
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + filename);
            Response.BinaryWrite(documentBinary);
            Response.Flush();
            Response.End();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert(' Attachment Not Available/ Error in Server');</script>");
        }
    }
    protected void status_btn_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (btnstatus.SelectedValue == "Rejected")
        {
            txtrearej.Visible = true;
        }
        else
        {
            txtrearej.Visible = false;
        }
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            if ((btnstatus.SelectedValue == "") && (btnstatus.SelectedValue == ""))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly select the status Accept/Reject!, Click OK');", true);
            }

            if (btnstatus.SelectedValue == "Rejected")
            {
                if (txtrearej.Text == "")
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly enter the reason for Rejection!, Click OK');", true);
                }

                else
                {
                    con.Open();
                    string strsqlcommand1 = "UPDATE [dbo].[VendorCyberSecurity] SET  [status] = 'Rejected', [ReasonForReject] = '" + txtrearej.Text + "'  where EmailAddress = '" + txtEmail.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(strsqlcommand1, con);
                    cmd1.ExecuteNonQuery();
                    con.Close();
                    Rejectmail();
                }
            }
            if (btnstatus.SelectedValue == "Approved")
            {
                con.Open();
                string strsqlcommand1 = "UPDATE [dbo].[VendorCyberSecurity] SET  [status] = 'Approved'  where EmailAddress = '" + txtEmail.Text + "'";
                SqlCommand cmd1 = new SqlCommand(strsqlcommand1, con);
                cmd1.ExecuteNonQuery();
                con.Close();
                Approvalmail();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }


    protected void Rejectmail()
    {
        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");
        msg.To.Add(txtEmail.Text);
        msg.CC.Add("Jaganathan.k@indo-mim.com");
        //msg.CC.Add("shalini.r@indo-mim.com");
        msg.Subject = "Vendor Cyber Security Questionnaire Rejected";

        msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";
        msg.Body += "<table style='width:450px'><tr><td><div align='center' style='width:400px; background-color: #0066CC; font-family: Calibri; font-size: medium; font-weight: bold; color: #FFFFFF;'> Please find below Vendor Cyber Security Questionnaire Rejected Details </div></td></tr><tr><td></td> </tr> <tr><td><table border='1' style='border: thin solid #C0C0C0; width: 450px;  font-family: Calibri;'><td>UserName</td><td>" + Convert.ToString(txtEmail.Text) + "</td></tr>   <td>Status</td><td>" + btnstatus.SelectedValue.ToString() + "</td></tr>  <tr> <td>Reason For Reject</td><td>" + Convert.ToString(txtrearej.Text) + "</td></tr>  </tr> </tr> <tr><td></td><td> </tr> </table>" + "<br/>";


        msg.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "192.168.1.71";
        smtp.Port = 25;
        smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        ScriptManager.RegisterStartupScript(this, this.GetType(),
           "alert",
           "alert('Rejected & mail sent to User successfully., Click OK');window.location ='NewQuestionnaireApproval.aspx';", true);
        try
        {
            smtp.Send(msg);
        }
        catch
        {
        }
    }


    protected void Approvalmail()
    {

        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");
        msg.To.Add(txtEmail.Text);
        msg.CC.Add("Jaganathan.k@indo-mim.com");
        //msg.CC.Add("shalini.r@indo-mim.com");
        msg.Subject = "Vendor Cyber Security Questionnaire Approved";

        msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";
        msg.Body = "<font color='black'>" +

        "<br/>" + "Dear" + " " + Convert.ToString(txtName.Text) + "" + "<br/>" +
        "<br/>" + "Thank You!! " + "<br/>" +
        "<br/>" + "Your INDO-MIM Cyber Security Questionnaire has been approved." + "<br/>" +
        "<br/>" + "Regards," + "<br/>" +
        "Information Security Team – INDO-MIM" + "<br/>";


        msg.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "192.168.1.71";
        smtp.Port = 25;
        smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        ScriptManager.RegisterStartupScript(this, this.GetType(),
                    "alert",
                    "alert('Approved & mail sent to User successfully., Click OK');window.location ='NewQuestionnaireApproval.aspx';", true);
        try
        {
            smtp.Send(msg);
        }
        catch
        {
        }
    }

    protected void SoftwareNameVerionGridQ6()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q6YesNo],[Q6Remarks]   from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView4.DataSource = dt;
                GridView4.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void SoftwareNameVerionGridQ61()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q6YesNo1],[Q6Remarks1]  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView5.DataSource = dt;
                GridView5.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void SoftwareNameVerionGridQ9()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q9YesNo],[Q9Remarks]   from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView6.DataSource = dt;
                GridView6.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void SoftwareNameVerionGridQ91()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q9YesNo1],[Q9Remarks1]  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView7.DataSource = dt;
                GridView7.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }
}

    

