﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;
using Microsoft.Reporting.WebForms;
using System.Text;
using System.Text.RegularExpressions;
using System.Data.OleDb;

public partial class NewRegisterApproval : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    EncryptDecrypt objEncryptDecrypt = new EncryptDecrypt();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gridload();
            gridloadApproval();
            gridloadReject();
            gridloadDisabled();
        }
    }


    protected void gridload()
    {
        try
        {
            SqlCommand cmd = new SqlCommand(@"SELECT [AutoID],[SupplierCompanyName],[Name],[EmailId],[Phone],CONVERT(varchar(50), Date,106)[Date] FROM [ITVendorLicences].[dbo].[LOGWITHUSER] where active = 0", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.CommandTimeout = 999999999;
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void gridloadApproval()
    {
        try
        {
            SqlCommand cmd = new SqlCommand(@"SELECT [AutoID],[SupplierCompanyName],[Name],[EmailId],[Phone],CONVERT(varchar(50), Date,106)[Date],[status] FROM [ITVendorLicences].[dbo].[LOGWITHUSER] where [status] = 'Approved' and EmailId <> 'admin'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.CommandTimeout = 999999999;
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView2.DataSource = dt;
            GridView2.DataBind();
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void gridloadReject()
    {
        try
        {
        SqlCommand cmd = new SqlCommand(@"SELECT [AutoID],[SupplierCompanyName],[Name],[EmailId],[Phone],CONVERT(varchar(50), Date,106)[Date],ReasonForReject,[status] FROM [ITVendorLicences].[dbo].[LOGWITHUSER] where [status] = 'Rejected'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        cmd.CommandTimeout = 999999999;
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView3.DataSource = dt;
        GridView3.DataBind();
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void gridloadDisabled()
    {
        try
        {
            SqlCommand cmd = new SqlCommand(@"SELECT [AutoID],[SupplierCompanyName],[Name],[EmailId],[Phone],CONVERT(varchar(50), Date,106)[Date],[status] FROM [ITVendorLicences].[dbo].[LOGWITHUSER] where [status] = 'Disabled'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.CommandTimeout = 999999999;
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView4.DataSource = dt;
            GridView4.DataBind();
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void btnApp_Click(object sender, EventArgs e)
    {
        var rowIndex = ((GridViewRow)((Control)sender).NamingContainer).RowIndex;
        {
            con.Open();
            Label AutoID = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("AutoID");
            Label EmailId = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("EmailId");
            Label Nme = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("Name");
            {
                string UNme = Nme.Text.Substring(0, 4);

                lblPass.Text = CreateRandomPassword(8);
               // string strpass = encryptpass(lblPass.Text);

                string strsqlcommand1 = "UPDATE [dbo].[LOGWITHUSER] SET  [status] = 'Approved' ,[Active] = '1',[UserName] = '" + EmailId.Text + "',[password]= @Password where autoid = '" + AutoID.Text + "'";
                SqlCommand cmd1 = new SqlCommand(strsqlcommand1, con);
                cmd1.Parameters.Add("@Password", SqlDbType.VarChar).Value = objEncryptDecrypt.Encrypt(lblPass.Text.ToString(), true);
                int roweffected = cmd1.ExecuteNonQuery();
                con.Close();



                MailMessage msg = new MailMessage();
                msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");
                msg.To.Add(EmailId.Text);
                //msg.CC.Add("Jaganathan.k@indo-mim.com");
                msg.CC.Add("shalini.r@indo-mim.com");
                msg.Subject = "Credential Details";

                msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";
                msg.Body += "<br/><font color='Black'>" + "Dear " + Convert.ToString(Nme.Text) + "" + "<br/>" + "<br/>";
                msg.Body += "<br/><font color='Black'>" + "Thanks for registering in INDO-MIM Cyber Security Questionnaire Portal. Please find below the Credentials to login to the portal." + "<br/>" + "<br/>";
                msg.Body += "<table style='width:450px'><tr><td></td></tr><tr><td></td> </tr> <tr><td><table border='1' style='border: thin solid #C0C0C0; width: 450px;  font-family: Calibri;'><tr> <td>UserName</td><td>" + Convert.ToString(EmailId.Text) + "</td></tr> <tr><td>Password</td><td> " + lblPass.Text + "</td> </tr> </tr> <tr><td></td><td> </tr> </table>" + "<br/>";

                msg.Body += "<br/><font color='Black'>" + "Important Note: DONOT share your login credentials with anyone. If you find your credentials are misused, kindly reset your password immediately or reach out to infosec@indo-mim.com" + "<br/>" + "<br/>";


                msg.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "192.168.1.71";
                smtp.Port = 25;
                smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                   "alert",
                   "alert('Approved & mail sent to User successfully, Click OK');window.location ='NewRegisterApproval.aspx';", true);
                try
                {
                    smtp.Send(msg);
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
                }
            }
        }
    }

    public string encryptpass(string password)
    {
        string msg = "";
        byte[] encode = new byte[password.Length];
        encode = Encoding.UTF8.GetBytes(password);
        msg = Convert.ToBase64String(encode);
        return msg;
    }

    protected void btnRej_Click(object sender, EventArgs e)
    {
        var rowIndex = ((GridViewRow)((Control)sender).NamingContainer).RowIndex;
        {
            con.Open();
            Label EmailId = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("EmailId");
            Label AutoID = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("AutoID");
            {
                lblPass.Text = AutoID.Text;
                lblemailid.Text = EmailId.Text;

            }
        }
        pnlpopup.Visible = true;
        txtreasonforrejection.Text = null;
        this.MSG.Show();
    }

    public static string CreateRandomPassword(int PasswordLength)
    {
        string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
        Random randNum = new Random();
        char[] chars = new char[PasswordLength];
        int allowedCharCount = _allowedChars.Length;
        for (int i = 0; i < PasswordLength; i++)
        {
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        if (txtreasonforrejection.Text == "")
        {
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Kindly enter the Reason For Reject.');", true);
            pnlpopup.Visible = true;
            txtreasonforrejection.Text = null;
            this.MSG.Show();
        }
        else
        {
            con.Open();
            string strsqlcommand1 = "UPDATE [dbo].[LOGWITHUSER] SET  [status] = 'Rejected' ,[Active] = '1',ReasonForReject = '" + txtreasonforrejection.Text + "' where autoid = '" + lblPass.Text + "'";
            SqlCommand cmd1 = new SqlCommand(strsqlcommand1, con);
            int roweffected = cmd1.ExecuteNonQuery();
            con.Close();



            MailMessage msg = new MailMessage();
            msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");
            msg.To.Add(lblemailid.Text);
            //msg.CC.Add("Jaganathan.k@indo-mim.com");
            msg.CC.Add("shalini.r@indo-mim.com");
            msg.Subject = "Login Rejected";

            msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";
            msg.Body += "<table style='width:450px'><tr><td><div align='center' style='width:400px; background-color: #0066CC; font-family: Calibri; font-size: medium; font-weight: bold; color: #FFFFFF;'> Please find below Login Rejected Details </div></td></tr><tr><td></td> </tr> <tr><td><table border='1' style='border: thin solid #C0C0C0; width: 450px;  font-family: Calibri;'><tr> <td>Reason For Reject</td><td>" + Convert.ToString(txtreasonforrejection.Text) + "</td></tr> </tr> </tr> <tr><td></td><td> </tr> </table>" + "<br/>";


            msg.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "192.168.1.71";
            smtp.Port = 25;
            smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
            ScriptManager.RegisterStartupScript(this, this.GetType(),
               "alert","alert('Rejected & mail sent to User successfully., Click OK');window.location ='NewRegisterApproval.aspx';", true);
            try
            {
                smtp.Send(msg);
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
            }
        }
    }
    protected void Disable_Click(object sender, EventArgs e)
    {
        var rowIndex = ((GridViewRow)((Control)sender).NamingContainer).RowIndex;
        {
            con.Open();
            Label AutoID = (Label)GridView2.Rows[rowIndex].Cells[0].FindControl("AutoID");
            Label EmailId = (Label)GridView2.Rows[rowIndex].Cells[0].FindControl("EmailId");
            Label Nme = (Label)GridView2.Rows[rowIndex].Cells[0].FindControl("Name");
            {
                string UNme = Nme.Text.Substring(0, 4);

                string strsqlcommand1 = "UPDATE [dbo].[LOGWITHUSER] SET  [status] = 'Disabled' ,[Active] = '2' where autoid = '" + AutoID.Text + "'";
                SqlCommand cmd1 = new SqlCommand(strsqlcommand1, con);
                int roweffected = cmd1.ExecuteNonQuery();
                con.Close();

                MailMessage msg = new MailMessage();
                msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");
                msg.To.Add(EmailId.Text);
                //msg.CC.Add("Jaganathan.k@indo-mim.com");
                msg.CC.Add("shalini.r@indo-mim.com");
                msg.Subject = "Credential Details";

                msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";
                msg.Body += "<table style='width:450px'><tr><td><div align='center' style='width:400px; background-color: #0066CC; font-family: Calibri; font-size: medium; font-weight: bold; color: #FFFFFF;'>  Your Account is been Disabled  </div></td></tr><tr><td></td> </tr> <tr><td><table border='1' style='border: thin solid #C0C0C0; width: 450px;  font-family: Calibri;'><tr> <td>User Name</td><td>" + EmailId.Text + "</td></tr> </tr> </tr> <tr><td></td><td> </tr> </table>" + "<br/>";


                msg.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "192.168.1.71";
                smtp.Port = 25;
                smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
                ScriptManager.RegisterStartupScript(this, this.GetType(),
                   "alert",
                   "alert('Disabled & mail sent to User successfully., Click OK');window.location ='NewRegisterApproval.aspx';", true);
                try
                {
                    smtp.Send(msg);
                }
                catch
                {
                }
            }
        }
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SET WIDTH OF THE COLUMNS
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[3].Width = Unit.Pixel(250); //Emailid
        }
    }
    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SET WIDTH OF THE COLUMNS
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[3].Width = Unit.Pixel(200); //Emailid
        }
    }
    protected void GridView3_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SET WIDTH OF THE COLUMNS
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[3].Width = Unit.Pixel(200); //Emailid
        }
    }
    protected void GridView4_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SET WIDTH OF THE COLUMNS
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[3].Width = Unit.Pixel(200); //Emailid
        }
    }
}
