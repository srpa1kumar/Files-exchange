﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;  
using System.Web.UI.HtmlControls;  
using System.Web.UI.WebControls;  
using System.Web.UI.WebControls.WebParts;  
using System.Xml.Linq;  
using System.Data.SqlClient; 
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;

public partial class ResetPassword : System.Web.UI.Page
{
    EncryptDecrypt objEncryptDecrypt = new EncryptDecrypt();
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }

    string str = null;
    SqlCommand com;
    byte up;
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            string EncryPassword = objEncryptDecrypt.Encrypt(txt_cpassword.Text.Trim(), true);
            Captcha1.ValidateCaptcha(txtCaptcha.Text.Trim());

            if (Captcha1.UserValidated)
            {
                SqlCommand cmd = new SqlCommand(@"select * from [LOGWITHUSER] where [EmailId] = '" + txtUserNme.Text + "'", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (EncryPassword == reader["Password"].ToString())
                    {
                        up = 1;
                    }
                }
                reader.Close();
                con.Close();
                if (txt_npassword.Text != txt_ccpassword.Text)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('Confirm Password does not match New Password.');</script>");
                }
                else
                {
                    if (up == 1)
                    {
                        con.Open();
                        str = "update LOGWITHUSER set Password = @Password where EmailId='" + txtUserNme.Text + "'";
                        com = new SqlCommand(str, con);
                        //com.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50));
                        //com.Parameters["@Password"].Value = txt_npassword.Text;
                        com.Parameters.Add("@Password", SqlDbType.VarChar).Value = objEncryptDecrypt.Encrypt(txt_npassword.Text.ToString(), true);
                        com.ExecuteNonQuery();
                        con.Close();
                        Mail();
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Password changed Successfully, Click OK');window.location ='Default.aspx';", true);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert('Please enter correct Current password / correct UserName.');</script>");
                    }
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "Invalid. Please try again.";
            }
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }


    protected void Mail()
    {
        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");

        ////---------------------Test Email ID------------------------------
        msg.To.Add(txtUserNme.Text);
        //msg.CC.Add("Jaganathan.k@indo-mim.com");
        msg.CC.Add("shalini.r@indo-mim.com");


        msg.Subject = "CSQ_Alert";
        msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";

        msg.Body += "<br/><font color='Black'>" + " Your password was changed  " + "<br/>";
        msg.Body += "<br /> <font color='Black'> LINK: <a href='http://192.168.1.73/demopage'>http://192.168.1.73/demopage</a></b><br/><br/>";
        msg.Body +=
   "<br/><br/><font color='black'>" + "<b>" +
"UserName:" + txtUserNme.Text + "<br/>" +
"Date :" + DateTime.Now.ToString("dd-MM-yyyy") + "<br/>" +
"Time :" + DateTime.Now.ToString("hh:mm:ss tt") + "<br/>" + "<br/>";

        // msg.Subject = "TEST MAIL.PLZ,IGNORE IT";

        msg.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();

        //***** Old Host ID ******
        //smtp.Host = "192.168.1.25";

        //***** New Host ID ******
        smtp.Host = "192.168.1.71";
        smtp.Port = 25;
        smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        try
        {
            smtp.Send(msg);
        }
        catch
        {
        }
    }
}
