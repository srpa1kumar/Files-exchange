﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;
using Microsoft.Reporting.WebForms;

public partial class NewRegisterApproval : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gridload();
            gridloadApproval();
            gridloadReject();
            BindEmaildropdown();
        }
    }

    protected void BindEmaildropdown()
    {
        SqlCommand cmd = new SqlCommand(@" select [EmailAddress]  FROM [ITVendorLicences].[dbo].[VendorCyberSecurity] where status = 'Approved' order by date desc ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        ddlEmail.DataSource = dt;
        ddlEmail.DataTextField = "EmailAddress";
        ddlEmail.DataValueField = "EmailAddress";
        ddlEmail.DataBind();
        ddlEmail.Items.Insert(0, "--Select--");
    }

    protected void gridload()
    {
        try
        {
            SqlCommand cmd = new SqlCommand(@"    select ROW_NUMBER() OVER(ORDER BY ID ASC) AS ID, [SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],Date from VendorCyberSecurity where Status IS NULL order by id desc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.CommandTimeout = 999999999;
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void gridloadApproval()
    {
        try
        {
            SqlCommand cmd = new SqlCommand(@"  select ROW_NUMBER() OVER(ORDER BY ID ASC) AS ID, [SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],Date,Status from VendorCyberSecurity where Status = 'Approved' order by id desc", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.CommandTimeout = 999999999;
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView2.DataSource = dt;
            GridView2.DataBind();
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void gridloadReject()
    {
        try
        {
            SqlCommand cmd = new SqlCommand(@"  select ROW_NUMBER() OVER(ORDER BY ID ASC) AS ID, [SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],Date,Status,ReasonForReject from VendorCyberSecurity where Status = 'Rejected' order by id desc ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            cmd.CommandTimeout = 999999999;
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView3.DataSource = dt;
            GridView3.DataBind();
        }

        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

   
    protected void btnApp_Click(object sender, EventArgs e)
    {
        try
        {
            var rowIndex = ((GridViewRow)((Control)sender).NamingContainer).RowIndex;
            {
                con.Open();
                Label AutoID = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("AutoID");
                Label EmailId = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("EmailId");
                Label Nme = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("Name");
                {
                    string UNme = Nme.Text.Substring(0, 4);

                    lblPass.Text = CreateRandomPassword(8);

                    string strsqlcommand1 = "UPDATE [dbo].[LOGWITHUSER] SET  [status] = 'Approved' ,[Active] = '1',[UserName] = '" + EmailId.Text + "',[password]='" + lblPass.Text + "' where autoid = '" + AutoID.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(strsqlcommand1, con);
                    int roweffected = cmd1.ExecuteNonQuery();
                    con.Close();



                    MailMessage msg = new MailMessage();
                    msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");
                    msg.To.Add(EmailId.Text);
                    //msg.CC.Add("Jaganathan.k@indo-mim.com");
                    msg.CC.Add("shalini.r@indo-mim.com");
                    msg.Subject = "Credential Details";

                    msg.Body += "<br/><font color='Red'>" + "*** This is an automatically generated email. please do not reply ***" + "<br/>" + "<br/>";
                    msg.Body += "<table style='width:450px'><tr><td><div align='center' style='width:400px; background-color: #0066CC; font-family: Calibri; font-size: medium; font-weight: bold; color: #FFFFFF;'> Please find below Credential Details </div></td></tr><tr><td></td> </tr> <tr><td><table border='1' style='border: thin solid #C0C0C0; width: 450px;  font-family: Calibri;'><tr> <td>UserName</td><td>" + Convert.ToString(EmailId.Text) + "</td></tr> <tr><td>Password</td><td> " + lblPass.Text + "</td> </tr> </tr> <tr><td></td><td> </tr> </table>" + "<br/>";


                    msg.IsBodyHtml = true;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "192.168.1.71";
                    smtp.Port = 25;
                    smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
                    ScriptManager.RegisterStartupScript(this, this.GetType(),
                       "alert",
                       "alert('Approved & mail sent to User successfully, Click OK');window.location ='NewRegisterApproval.aspx';", true);
                    try
                    {
                        smtp.Send(msg);
                    }
                    catch
                    {
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }


    protected void btnRej_Click(object sender, EventArgs e)
    {
        var rowIndex = ((GridViewRow)((Control)sender).NamingContainer).RowIndex;
        {
            con.Open();
            Label AutoID = (Label)GridView1.Rows[rowIndex].Cells[0].FindControl("AutoID");
            {
                lblPass.Text = AutoID.Text;
            }
        }
    }

    public static string CreateRandomPassword(int PasswordLength)
    {
        string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
        Random randNum = new Random();
        char[] chars = new char[PasswordLength];
        int allowedCharCount = _allowedChars.Length;
        for (int i = 0; i < PasswordLength; i++)
        {
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }


 
  
    protected void ddlEmail_SelectedIndexChanged(object sender, EventArgs e)
    {
        DownloadFile();
        con.Open();
        SqlCommand cmd = new SqlCommand(@" Select * from [LOGWITHUSER] where EmailId = '" + ddlEmail.SelectedItem.Text + "'", con);
        SqlDataAdapter da_drc = new SqlDataAdapter(cmd);
        DataTable dt_drc = new DataTable();
        da_drc.Fill(dt_drc);
        con.Close();
        ReportDataSource dc_mol = new ReportDataSource();
        dc_mol.Name = "DataSet1";
        dc_mol.Value = dt_drc;


        con.Open();
        SqlCommand cmd1 = new SqlCommand(@"  select * FROM [ITVendorLicences].[dbo].[VendorCyberSecurity] where EmailAddress = '" + ddlEmail.SelectedItem.Text + "'", con);
        SqlDataAdapter da_drc1 = new SqlDataAdapter(cmd1);
        DataTable dt_drc1 = new DataTable();
        da_drc1.Fill(dt_drc1);
        con.Close();
        ReportDataSource dc_mol1 = new ReportDataSource();
        dc_mol1.Name = "DataSet2";
        dc_mol1.Value = dt_drc1;


        con.Open();
        SqlCommand cmd2 = new SqlCommand(@" SELECT  [Id],[SupplierCompanyName],[Name],[EmailAddress],[PhoneNumber],[T1SoftwareName],[T1Version],[T1Description] 
,[T1LicenseType],[T1LicenseSubscriptionModel],CONVERT(varchar,T1ValidFrom,1)[T1ValidFrom],CONVERT(varchar,T1ValidTill,1)[T1ValidTill],[Date],[Q6YesNo]
      ,[Q6Remarks],[Q9YesNo],[Q9Remarks] FROM [ITVendorLicences].[dbo].[VendorCyberSecurityGrid1] where EmailAddress = '" + ddlEmail.SelectedItem.Text + "'", con);
        SqlDataAdapter da_drc2 = new SqlDataAdapter(cmd2);
        DataTable dt_drc2 = new DataTable();
        da_drc2.Fill(dt_drc2);
        con.Close();
        ReportDataSource dc_mol2 = new ReportDataSource();
        dc_mol2.Name = "DataSet3";
        dc_mol2.Value = dt_drc2;

        con.Open();
        SqlCommand cmd3 = new SqlCommand(@" select * FROM [ITVendorLicences].[dbo].[VendorCyberSecurityGrid2] where EmailAddress = '" + ddlEmail.SelectedItem.Text + "' ", con);
        SqlDataAdapter da_drc3 = new SqlDataAdapter(cmd3);
        DataTable dt_drc3 = new DataTable();
        da_drc3.Fill(dt_drc3);
        con.Close();
        ReportDataSource dc_mol3 = new ReportDataSource();
        dc_mol3.Name = "DataSet4";
        dc_mol3.Value = dt_drc3;

        ReportViewer1.Visible = true;
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(dc_mol);
        ReportViewer1.LocalReport.DataSources.Add(dc_mol1);
        ReportViewer1.LocalReport.DataSources.Add(dc_mol2);
        ReportViewer1.LocalReport.DataSources.Add(dc_mol3);
        ReportViewer1.LocalReport.Refresh();
    }

    string var1;
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        var1 = GridView1.SelectedRow.Cells[4].Text;
        Response.Redirect("~/ApprovalVendorCyberSecurityQuestionnaire.aspx?DOC=" + var1 + "");
    }

    private void DownloadFile()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand(@" select id, [ContentName] ,[ContentType],[Content]from [ITVendorLicences].[dbo].[VendorCyberFileUpload] where [EmailAddress] = '" + ddlEmail.SelectedItem.Text + "' ", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        if (dt.Rows.Count > 0)
        {
            downGrid.DataSource = dt;
            downGrid.DataBind();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        byte[] documentBinary;
        GridViewRow gvr = ((Button)sender).Parent.Parent as GridViewRow;
        Label ID = (Label)gvr.FindControl("ID");
        string filename = string.Empty;
        con.Open();
        SqlCommand com = new SqlCommand(" select id, [ContentName] ,[ContentType],[Content]from [ITVendorLicences].[dbo].[VendorCyberFileUpload] where [EmailAddress] = '" + ddlEmail.SelectedItem.Text + "' and id = '" + ID.Text + "' ", con);

        try
        {
            using (SqlDataReader sdr = com.ExecuteReader())
            {
                sdr.Read();
                // bytes = (byte[])sdr["fileattachment"];
                documentBinary = (byte[])sdr["Content"];

                filename = sdr["ContentName"].ToString();
            }
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + filename);
            Response.BinaryWrite(documentBinary);
            Response.Flush();
            Response.End();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>alert(' Attachment Not Available/ Error in Server');</script>");
        }
    }

    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SET WIDTH OF THE COLUMNS
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[3].Width = Unit.Pixel(200); //Emailid
        }
    }
    protected void GridView3_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SET WIDTH OF THE COLUMNS
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[3].Width = Unit.Pixel(200); //Emailid
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //SET WIDTH OF THE COLUMNS
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[3].Width = Unit.Pixel(200); //Emailid
        }
    }
}
