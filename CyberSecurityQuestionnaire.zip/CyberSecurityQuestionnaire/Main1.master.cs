﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Net;
using System.Text;

public partial class Main : System.Web.UI.MasterPage
{
    string username;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            //Response.Redirect("TaxtranDetails.aspx");
            //if (Session["Name"] == null)
            //{
            //    Response.Redirect("default.aspx");
            //}

        }
       // txtLogName.Text = Session["Name"].ToString();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedItem.Text == "Registry Approval Page")
        {
            Response.Redirect("NewRegisterApproval.aspx");
        }
        if (DropDownList1.SelectedItem.Text == "Questionnaire Approval Page")
        {
            Response.Redirect("NewQuestionnaireApproval.aspx");
        }
    }
}
