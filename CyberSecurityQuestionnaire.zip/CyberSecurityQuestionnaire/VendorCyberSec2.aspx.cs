﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Drawing;
using System.Net.Mail;

public partial class VendorCyberSec2 : System.Web.UI.Page
{
    string Name; string EmailID;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HoskoteConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Name"] == null)
            {
                Response.Redirect("default.aspx");

            }

            EmailID = Session["EmailID"].ToString(); // value of EmailIDTextBox;
            Name = Session["Name"].ToString();
            txtformDate.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
            loadGrid();

            SoftwareNameVerionGrid();
            SoftwareNameVerionGrid2();
        }
    }

    protected void SoftwareNameVerionGrid()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T1SoftwareName] + ' - ' + [T1Version])SoftwareNameVersion,[Q6Remarks] as Remarks  from [dbo].[VendorCyberSecurityGrid1] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView3.DataSource = dt;
                GridView3.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void SoftwareNameVerionGrid2()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@"  select id,([T2SoftwareName] + ' - ' + [T2Version])SoftwareNameVersion,[Q6Remarks1] as Remarks  from [dbo].[VendorCyberSecurityGrid2] where [EmailAddress] = '" + txtEmail.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                GridView4.DataSource = dt;
                GridView4.DataBind();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }

    protected void loadGrid()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(@" Select * from [LOGWITHUSER] where EmailId = '" + EmailID + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                txtSupCompNme.Text = Convert.ToString(dt.Rows[0]["SupplierCompanyName"]);
                txtName.Text = Convert.ToString(dt.Rows[0]["Name"]);
                txtEmail.Text = Convert.ToString(dt.Rows[0]["EmailId"]);
                txtphone.Text = Convert.ToInt64(dt.Rows[0]["Phone"]).ToString();
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
        con.Close();
    }


    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            grid3update();
            ScriptManager.RegisterStartupScript(this, this.GetType(),
            "alert",
            "alert('Data Saved and Mail sent to concern person Successfully, Click OK');window.location ='Default.aspx';", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "err_msg", "alert('" + ex.Message + "');", true);
        }
    }

    protected void Save()
    {
        SqlCommand cmd = new SqlCommand(@"  update [VendorCyberSecurity] set [Q8YesOrNo] = '"+RdQ8YesNo.Text+"',[Q10YesOrNo]='"+RdQ10YesNo.Text+@"',
[Q10mitigation]='"+RdQ10.Text+"',[FormFilledByName]='"+txtFormName.Text+"',[FormFilledByDesignation]='"+txtFormDesg.Text+@"'
      ,[FormFilledByDateOfSubmission]='"+txtformDate.Text+"' where [EmailAddress] = '"+txtEmail.Text+"'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        //Mail();
    }

    protected void grid3update()
    {

        int totalRows = GridView3.Rows.Count;
        for (int RowIndex = 0; RowIndex < totalRows; RowIndex++)
        // foreach (GridViewRow gvr in GridView3.Rows)
        {
            GridViewRow row = GridView3.Rows[RowIndex];
            Label id = row.FindControl("id") as Label;
            DropDownList YesNo = row.FindControl("ddlyesno") as DropDownList;
            TextBox Remarks = row.FindControl("Remarks") as TextBox;
            // TextBox Remarks = (TextBox)row.FindControl("Remarks");

            if (YesNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly selet Yes/No!, Click OK');", true);
            }
            if (YesNo.SelectedItem.Text != "--Select--")
            {
                SqlCommand cmd = new SqlCommand("UPDATE [VendorCyberSecurityGrid1] SET Q9YesNo = @Q9YesNo,Q9Remarks = @Q9Remarks WHERE id = @id", con);
                cmd.Parameters.AddWithValue("@Q9YesNo", YesNo.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@Q9Remarks", Remarks.Text);
                cmd.Parameters.AddWithValue("@id", id.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                grid3update2();
            }
        }
        // Response.Redirect(Request.Url.AbsoluteUri);
    }

    protected void grid3update2()
    {
        int totalRows = GridView4.Rows.Count;
        for (int RowIndex = 0; RowIndex < totalRows; RowIndex++)
        // foreach (GridViewRow gvr in GridView3.Rows)
        {
            GridViewRow row = GridView4.Rows[RowIndex];
            Label id = row.FindControl("id") as Label;
            DropDownList YesNo = row.FindControl("ddlyesno") as DropDownList;
            TextBox Remarks = row.FindControl("Remarks") as TextBox;
            // TextBox Remarks = (TextBox)row.FindControl("Remarks");

            if (YesNo.SelectedItem.Text == "--Select--")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Kindly selet Yes/No!, Click OK');", true);
            }
            if (YesNo.SelectedItem.Text != "--Select--")
            {
                SqlCommand cmd = new SqlCommand("UPDATE [VendorCyberSecurityGrid2] SET Q9YesNo1 = @Q9YesNo,Q9Remarks1 = @Q9Remarks WHERE id = @id", con);
                cmd.Parameters.AddWithValue("@Q9YesNo", YesNo.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@Q9Remarks", Remarks.Text);
                cmd.Parameters.AddWithValue("@id", id.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Save();
            }
        }
    }

    protected void Mail()
    {
        string from = "IT@indo-mim.com";
        MailMessage msg = new MailMessage();
        msg.From = new MailAddress("communiq@indo-mim.com", "CSQ_Alert");
        msg.To.Add(txtEmail.Text);
        //msg.CC.Add("Jaganathan.k@indo-mim.com");
        msg.CC.Add("shalini.r@indo-mim.com");
        msg.Subject = "Cyber Security Questionnaire";

        msg.Body = "<font color='black'>" +

        "<br/>" + "Dear" +" "+   Convert.ToString(txtName.Text) + "" + "<br/>" +
        "<br/>" + "Thank You!!Cyber Security Questionnaire has been submitted successfully by " + Convert.ToString(txtName.Text) + " on " + txtformDate.Text + ". " + "<br/>" + "<br/>" +
        "<br/>" + "As a next step, our Information Security Team will go through your submission and get back to you accordingly. Once your submission is approved, you will receive a copy of your submission in a PDF file format. Kindly wait for Approval." + "<br/>" +
        "<br/>" + "Our team will get back to you for any changes or correction that may be required to be done on your submission. If rejected, you will receive an email with the reason for rejection." + "<br/>"+
        "<br/>" + "Appreciate your efforts on this regard.  Thanks." + "<br/>"+
        "<br/>" + "For any queries, kindly reach out to infosec@indo-mim.com" + "<br/>"+
        "<br/>" + "Regards," + "<br/>"+
        "Information Security Team – INDO-MIM" + "<br/>";

        msg.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "192.168.1.71";
        smtp.Port = 25;
        smtp.Credentials = new System.Net.NetworkCredential("communiq@indo-mim.com", "comm" + "122");
        try
        {
            smtp.Send(msg);
        }
        catch
        {
        }
    }
}